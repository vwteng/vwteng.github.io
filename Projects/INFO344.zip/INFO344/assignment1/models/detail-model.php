<?php
class Movies {
    protected $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function search($id) {
        $sql = "select * from movies where id =?";
        $stmt = $this->conn->prepare($sql);
        $success = $stmt->execute(array($id));

        if (!$success) {
            trigger_error($stmt->errorInfo());
            return false;
        } else {
            return $stmt->fetchAll();
        }
    }
}

?>