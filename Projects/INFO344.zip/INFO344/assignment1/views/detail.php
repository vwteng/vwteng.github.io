<?php foreach($matches as $match): 

// Formatting date from database
date_default_timezone_set("America/New_York");
$originalDate = $match['released'];
$newDate = date("F j, Y", strtotime($originalDate));
// $poster = $movieData->Poster
?>

<header>
    <h1><?= htmlentities($match['title']) ?></h1>
</header>

<div class="container">
    <h2>About the Movie</h2>
    <table class="table details">
        <tr>
            <td>Released:</td>
            <td><?= htmlentities($newDate) ?></td>
        </tr>
        <tr>
            <td>Distributed By:</td>
            <td><?= htmlentities($match['distributor']) ?></td>
        </tr>
        <tr>
            <td>Genre:</td>
            <td><?= htmlentities($match['genre']) ?></td>
        </tr>
        <tr>
            <td>Rated:</td>
            <td><?= htmlentities($match['rating']) ?></td>
        </tr>
        <tr>
            <td>Tickets Sold:</td>
            <td><?= htmlentities(number_format($match['tickets'])) ?></td>
        </tr>
        <tr>
            <td>Gross Revenue:</td>
            <td><?= htmlentities('$' . number_format($match['gross'])) ?></td>
        </tr>
        <tr>
            <td>Plot:</td>
            <td><?= htmlentities($movieData->Plot) ?></td>
        </tr>
    </table>
    
    <h2>Rotten Tomatoes Rating</h2>
    <table class="table details">
        <tr>
            <td>Tomato Meter:</td>
            <td><?= htmlentities(  $movieData->tomatoMeter) ?>%</td>
        </tr>
        <tr>
            <td>Number of Reviews:</td>
            <td><?= htmlentities($movieData->tomatoReviews) ?></td>
        </tr>
        <tr>
            <td>Average Rating:</td>
            <td><?= htmlentities($movieData->tomatoRating) ?> out of 10</td>
        </tr>
        <tr>
            <td>Critics Consensus:</td>
            <td><?= htmlentities($movieData->tomatoConsensus) ?></td>
        </tr>
    </table>
</div>
<?php endforeach; ?>