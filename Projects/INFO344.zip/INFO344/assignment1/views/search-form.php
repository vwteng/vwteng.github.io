<form action="" method="GET">
    <div class="form-group">
        <input type="text"
            id="titleInput" 
            name="title"
            class="" 
            value="<?= htmlentities($title) ?>"
            placeholder="Search by title"
            >
    </div>
</form>