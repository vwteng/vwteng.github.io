<table class="table">
    <thead>
    <!--Column names-->
    <tr class="col-name">
        <td>Title</td>
        <td>Release Date</td>
        <td>Tickets Sold</td>
        <td>Gross Revenue</td>
    </tr>
    </thead>
    
    <?php foreach($matches as $match): 
    // Formatting date from database
    date_default_timezone_set("America/New_York");
    $originalDate = $match['released'];
    $newDate = date("j-M-Y", strtotime($originalDate));
    ?>
    
    <tr>
        <td class="title"> <?php echo('<a href="/movie.php?id=' . $match['id'] . '">' . $match['title'] . '</a>'); ?> </td>
        <td> <?= htmlentities($newDate) ?> </td>
        <td> <?= htmlentities(number_format($match['tickets'])) ?> </td>
        <td> <?= htmlentities('$' . number_format($match['gross'])) ?> </td>
    </tr>
    <?php endforeach; ?>
</table>