<?php
require_once 'connection.php';
require_once 'models/movie-model.php';

$title = $_GET['title'];

$conn = getConnection();
$movieModel = new Movies($conn);
$matches = $movieModel->search($title);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Movies</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header><h1>Movie Revenues From 2014</h1></header>
    <div class="container">
    <?php
    include 'views/search-form.php';

    if (count($matches) == 0) {
        echo('<p>No movies found with a title matching "' . $title . '"</p>');
    } else {
        include 'views/matches.php';
    }
    ?>
    
    </div>
    
    <a style="padding:15px" href="https://github.com/INFO344-win-2016/challenges-vwteng/tree/master/assignment1">Assignment 1 GitHub repo</a>
</body>
</html>