<?php
require_once 'connection.php';
require_once 'models/detail-model.php';

$id = $_GET['id'];

$conn = getConnection();
$movieModel = new Movies($conn);
$matches = $movieModel->search($id);

// Load data from OMDB API for current movie using the IMDB ID
$i = $matches[0]['imdb_id'];
$url = "http://www.omdbapi.com/?i={$i}&tomatoes=true";
$json = file_get_contents($url);
$movieData = json_decode($json);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Movies</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    include 'views/detail.php';
    ?>
</body>
</html>