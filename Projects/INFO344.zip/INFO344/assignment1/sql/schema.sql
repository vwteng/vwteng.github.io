drop table if exists movies;

create table movies (
    title varchar(128),
    released date,    
    distributor varchar(128),
    genre varchar(128),
    rating varchar(128),
    gross int,
    tickets int,
    imdb_id varchar(128),
    id int(3) not null auto_increment primary key
);