load data infile '~/challenges-vwteng/assignment1/data/movies-2014.csv'
into table movies
fields terminated by ','
optionally enclosed by '"'
ignore 1 lines
(title, released, distributor, genre, rating, gross, tickets, imdb_id);