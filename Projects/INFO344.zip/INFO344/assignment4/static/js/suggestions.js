$(document).ready(function() {
    // set a delay after a key is pressed
    var delay = (function(){
        var timer = 0;
        return function(callback, ms){
            clearTimeout (timer);
            timer = setTimeout(callback, ms);
        };
    })();
    
    // when a user types into the input
    $("input").keyup(function(e){
        delay(function(){
            // clears the results so new items can be added
            $("#results").empty();
            // get current q and max from input by user
            var q = ($('input[name=q]').val()).toLowerCase(); // convert q to lowercase
            var max = $('input[name=max]').val();
            
            // check that the max is between the values of 10 and 50
            if (max < 10 || max > 50) { // if max is not in valid range, an error appears
                $('#errorMessage').html("Maximum value should be between 10 and 50");
            } else { // max is set correctly
                $('#errorMessage').html(""); // clear the error message
                // ajax call route to get suggestions
                $.ajax({
                    type: "GET",
                    url: "/api/v1/suggestions",
                    data: { q: q, max: max },
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    
                    success: function(data) {
                        // goes through the data to display the results with hyperlinks to the wiki page
                        for (var i = 0; i < data.length; i++) {
                            $("#results").append("<li> <a href=\"https://en.wikipedia.org/wiki/" + data[i] + "\">" + data[i] + "</a></li>");
                        }
                    }
                });        
            }
        }, 100 );
    });
});