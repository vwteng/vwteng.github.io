package trie

import (
    "sort"
    "os"
    "bufio"
    "log"
    "strings"
    "runtime"
    "sync"
)

var memstats = new(runtime.MemStats)

// Trie struct with Root node and number of items in trie
type Trie struct {
    Root *Node
    Items int
    mx sync.RWMutex
}

// NewTrie func to create a new trie
func NewTrie() *Trie {
    return &Trie{Root: NewNode(0)}
}

// ItemsTotal func that returns an int of how many items are inside the trie
func (trie *Trie) ItemsTotal() int {
    return trie.Items
}

// LoadFile func to insert items in trie using the file selected
func (trie *Trie) LoadFile(file string) {
     // open the file
    txtfile, err := os.Open(file)
    
    if err != nil {
        log.Fatal(err)
    } else {
        scanner := bufio.NewScanner(txtfile)
        // process each line in the file
        for scanner.Scan() {
            runtime.ReadMemStats(memstats)
            // load file only up to memory usage 
            // ** file loads from the beginning and will load up the words beginning with 'a' **
            if memstats.Alloc < 4850000000 { // load up to approx 5gb with swap file
                trie.AddEntry(strings.ToLower(scanner.Text()))
            } else {
                break
            }
        }
        if err = scanner.Err(); err != nil {
            log.Fatal(err)
        }
    }
    
    defer txtfile.Close()
}

// AddEntry func to add the given entry string into trie
func (trie *Trie) AddEntry(entry string) {
    trie.mx.Lock()
    defer trie.mx.Unlock()
    // put rune of entry string into an array
    chars := []rune(entry)
    // update the item counter in the trie to increase by 1
    trie.Items = (trie.Items + 1)
    // call the helper method add to go through the word to add to the trie
    trie.Root.add(chars)
}

// add func to add each letter in trie
func (Root *Node) add(chars []rune) {
    // check to see if there are more letters to add
    if len(chars) > 0 {
        // check if a node already exists for the given letter
        if Root.Children[chars[0]] == nil {
            Root.Children[chars[0]] = NewNode(chars[0])
        }
        // recursive call to get the next letter in word
        Root.Children[chars[0]].add(chars[1:])
    } else { // end of the word, so Root.FullWord is set to true
        Root.FullWord = true
    }
}

// FindEntries func to find words that match the prefix and finds up to the max given
func (trie *Trie) FindEntries(prefix string, max uint64) []string {
    trie.mx.RLock()
    defer trie.mx.RUnlock()
    
    // array created to return with results
    var matches []string
    pref := []rune(prefix)
    var word string
    
    // check that the prefix is not blank
    if prefix != "" {
         matches = trie.Root.findPrefix(pref, max, word, matches)
    }
    // returns the array of matches 
    return matches
}

// FindPrefix func to go through trie up to the given prefix 
func (Root *Node) findPrefix(prefix []rune, max uint64, word string, matches []string) []string {
    if len(prefix) > 0 { // still have letters in prefix to look for
        if Root.Children[prefix[0]] != nil { 
            word += string(prefix[0]) // build up word
            matches = Root.Children[prefix[0]].findPrefix(prefix[1:], max, word, matches)
        }
    } else { // finished looking for prefix
        if Root.FullWord { // if prefix is a word, add to array
            matches = append(matches, word)
        }
        // look for words that has the prefix for matches
        matches = Root.findMatch(word, max, matches)
    }
    // returns the array of matches
    return matches
}

// FindMatch func to go through trie for words that contain  the prefix up to the max number of results
func (Root *Node) findMatch(word string, max uint64, matches []string) []string{
    // sort the keys in the map to get the letters in order for searching
    var keys []int
    for k := range Root.Children {
        keys = append(keys, int(k))
    }
    sort.Ints(keys)
    
    // look through keys to find the next words that includes the prefix
    for _, char := range keys {
        char := rune(char)
        word := word + string(char)
        // still has children
        if len(Root.Children[char].Children) > 0 {
            // check if the number of matches is less than the max to look for
            if len(matches) < int(max) {
                // check if a full word is found, add it to the matches array
                if Root.Children[char].FullWord {
                    matches = append(matches, word)
                }
                // look for matches at the given letter
                matches = Root.Children[char].findMatch(word, max, matches)
            }
        } else { // no more children, add the last word
            // check if the number of matches is less than the max to look for
            if len(matches) < int(max) {
                matches = append(matches, word)
            }
        }
    }
    // return the array of matches
    return matches
}

// Node struct that includes the letter, if it is a full word and a map of its children nodes
type Node struct {
    Letter rune
    FullWord bool
    Children map[rune]*Node
}

// NewNode function that creates a node for the given letter
func NewNode(letter rune) *Node {
    return &Node{Letter: letter, FullWord: false, Children: make(map[rune]*Node)}
}