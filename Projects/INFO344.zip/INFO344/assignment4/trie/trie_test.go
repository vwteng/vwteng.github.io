package trie

import (
    "testing"
)

// Test AddEntry to check that the items are being added to the trie
func TestAddEntry(t *testing.T) {
    // create new trie and add 3 items
    tr := NewTrie()
    tr.AddEntry("apple")
    tr.AddEntry("apricot")
    tr.AddEntry("banana")
    
    if tr.ItemsTotal() != 3 {
        t.Errorf("Items total expected to be 3, but %d was found instead", tr.ItemsTotal())
    }
}

// Test FindEntries to check that items are found correctly
func TestFindEntries(t *testing.T) {
    // create new trie and add 3 items
    tr := NewTrie()
    tr.AddEntry("apple")
    tr.AddEntry("apricot")
    tr.AddEntry("banana")
    
    // looking for entries that begin with 'a' for a max of 5 results
    results := tr.FindEntries("a", 5)
    
    if len(results) != 2 {
        t.Errorf("Entries found expected to be 2, but %d was found instead", len(tr.FindEntries("a", 5)))
    }
}

// Test FindEntries to check that items are found correctly and only up to the max results set
func TestFindEntriesLimit(t *testing.T) {
    // create new trie and add 3 items
    tr := NewTrie()
    tr.AddEntry("apple")
    tr.AddEntry("apricot")
    tr.AddEntry("banana")
    
    // looking for entries that begin with 'a' for a max of 1 result
    results := tr.FindEntries("a", 1)
    
    if len(results) != 1 {
        t.Errorf("Entries found expected to be 1, but %d was found instead", len(tr.FindEntries("a", 1)))
    }
}

// Test FindEntries when prefix does not exist to check that no items are found
func TestFindEntriesNone(t *testing.T) {
    // create new trie and add 3 items
    tr := NewTrie()
    tr.AddEntry("apple")
    tr.AddEntry("apricot")
    tr.AddEntry("banana")
    
    // looking for entires that begin with 'x' for a max of 5 results
    // using a trie that does not include a word that begins with 'x'
    results := tr.FindEntries("x", 5)
    
    if len(results) != 0 {
        t.Errorf("Entries found expected to be 0, but %d was found instead", len(tr.FindEntries("x", 5)))
    }
}