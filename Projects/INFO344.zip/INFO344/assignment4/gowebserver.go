package main

import (
    "github.com/vwteng/challenges-vwteng/assignment4/trie"
    "fmt"
    "os"
    "encoding/json"
    "log"
    "net/http"
    "strconv"
)

func main() {
    // create new trie
    tr := trie.NewTrie()
    
    // choose file to load, uses default unless user specifies in the command line argument
    // file used are stored inside folder named 'data'
    file := "./data/enwiki-latest-all-titles-in-ns0" 
    if len(os.Args) > 1 {
        if _, err := os.Stat(os.Args[1]); err == nil {
            file = os.Args[1]
        }
    }
    
    // load the file into trie
    go tr.LoadFile(file)
    
    // serve static files
    http.Handle("/", http.FileServer(http.Dir("./static")))
    // api call to get suggestions
    http.HandleFunc("/api/v1/suggestions", func (w http.ResponseWriter, r *http.Request) {
        // get the query and max value sent from ajax      
        q := r.FormValue("q")
        max, _ := strconv.ParseUint(r.FormValue("max"), 10, 64)        
        
        // find entries from the trie with the given query prefix and returns up to the maximum results
        resp := tr.FindEntries(q, max)
        
        // convert struct to JSON
        j, err := json.Marshal(resp)
        if nil != err {
            log.Println(err)
            w.WriteHeader(500)
            w.Write([]byte(err.Error()))
        } else {
            // tell the client we are sending back JSON
            w.Header().Add("Content-Type", "application/json")
            w.Write(j)
        }
    })
    
    fmt.Println("Server listening on port 9000...")
    http.ListenAndServe(":9000", nil)
}   