$(document).ready(function() {
    // display user's profile and fields they can update
    $.getJSON('/api/info', function(data) {
        // display all the information stored about a user, which includes:
        // their username (email for local users & id for oauth users), and display name
        $("#username").append("<span id=\"user\"> Profile for: " + data.username + "</span>");
        $("#displayName").append("<span> Display name: " + data.displayName + "</span>");

        // oauth users cannot change password since they don't it stored locally
        // hide the password update fields in the form
        if(data.password == undefined) {
            $( "#updatePassword" ).hide();
        }
        // fill out form with current display name
        $('input[name="displayName"]').val(data.displayName);
    });
    
    // display user's gravatar
    $.getJSON('/api/avatar', function(data) {
        $('<img />', {
        src: 'http://www.gravatar.com/avatar/' + data,
        width: '100px',
        height: '100px'
        }).appendTo($('#avatar').empty())
    });
    
    // when user clicks on the update display name button
    $('#updateNameForm').submit(function() {
        // storing user's input data to update
        var username = $('#user').text();
        var displayName = $('input[name=displayName]').val();
        
        // using ajax to change display name without refreshing page
        $.ajax({
            type: 'PUT',
            url: '/api/updateName',
            data: { username: username, displayName: displayName },
            success: function(res) {
                // updates the current display name
                $("#displayName").empty();
                $("#displayName").append("<span> Display name: " + res.displayName + "</span>");
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
       });
       return false;
    });
 
    // when user clicks on the update password button
    $('#updatePasswordForm').submit(function() {
        // storing user's input data to update
        var username = $('#user').text();
        var password = $('input[name=password]').val();
        var newPassword = $('input[name=newPassword]').val();
        var newPassword2 = $('input[name=newPassword2]').val();
        var displayName = $('input[name=displayName]').val();
        
        $.ajax({
            type: 'PUT',
            url: '/api/updatePassword',
            data: { username: username, password: password, newPassword: newPassword, newPassword2: newPassword2, displayName: displayName },
            success: function(res) {     
                // if there is an error, display the message on page
                if (res.error) {
                    $('#errorMessage').html(res.error);
                // successful password update, reload profile page
                } else {
                    window.location.href = '/profile.html';
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
       });
       return false;
    });
});