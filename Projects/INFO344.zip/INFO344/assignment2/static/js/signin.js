$(document).ready(function() {
    // when user clicks on the sign in button
    $('#signinForm').submit(function() {
        // storing user's input to pass into passport for authentication
        var username = $('input[name=username]').val();
        var password = $('input[name=password]').val();
        
        // showing visual feedback that the sign-in is happening
        $('#loading').show();
        
        $.ajax({
            type: 'POST',
            url: '/api/signin',
            data: { username: username, password: password },
            success: function(res) {
                // removing visual feedback
                $('#loading').hide();
                // if there is an error, display the message on page
                if (res.error) {
                    $('#errorMessage').html(res.error);
                // successful authentication, redirect to secure page
                } else {
                    window.location.href = res;
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
       });
       return false;
    });
});