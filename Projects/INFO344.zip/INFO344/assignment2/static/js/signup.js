$(document).ready(function() {
    // when user clicks on the create account button
    $('#signupForm').submit(function() {
        // storing user's input to pass into passport for authentication
        var username = $('input[name=username]').val();
        var password = $('input[name=password]').val();
        var password2 = $('input[name=password2]').val();
        var displayName = $('input[name=displayName]').val();
        
        $.ajax({
            type: 'POST',
            url: '/api/signup',
            data: { username: username, password: password, password2: password2, displayName: displayName },
            success: function(res) {
                // if there is an error, display the message on page
                if (res.error) {
                    $('#errorMessage').html(res.error);
                // successful signed up, redirect to secure page
                } else {
                    window.location.href = res;
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
       });
       return false;
    });
});
