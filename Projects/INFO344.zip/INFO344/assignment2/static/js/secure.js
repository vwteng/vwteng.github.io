$(document).ready(function() {
    //  get user's display name onto page
    $.getJSON('/api/info', function(data) {
        $("#name").append("<span>" + data.displayName + "</span>");
    });
});