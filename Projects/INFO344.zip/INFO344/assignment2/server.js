'use strict';

var express = require('express');
var app = express();
var mongoose = require('mongoose');
var passport = require('passport');
var session = require('express-session');
var RedisStore = require('connect-redis')(session);
var morgan = require('morgan');
var bodyParser = require('body-parser');

var configDB = require('./config/database.js');

// checks and sets the environment variable 
var cookieSigSecret = process.env.COOKIE_SIG_SECRET;
if (!cookieSigSecret) {
    console.error('Please set COOKIE_SIG_SECRET');
    process.exit(1);
}

// configure mongodb
var dbConfig = require('./secret/config-mongo.json');
mongoose.connect(dbConfig.url);

require('./config/passport')(passport);

app.use(morgan('dev'));

// add session support to the application,
// store session data in local Redis database
app.use(session({
    secret: cookieSigSecret,
    resave: false,
    saveUninitialized: false
    , store: new RedisStore()
}));

app.use(bodyParser());
app.use(bodyParser.json());

app.use(passport.initialize()); // add authentication to the app
app.use(passport.session());    // add session support to the app

require('./app/routes.js')(app, passport);

// tell express to serve static files from the /static/public
// subdirectory (any user can see these)
app.use(express.static(__dirname + '/static/public'));
app.use('/css', express.static(__dirname + '/static/css'));
app.use('/js', express.static(__dirname + '/static/js'));

// check to see user is authenticated to continue to process,
// if not, user is redirected back to the homepage
app.use(function(req, res, next) {
    if(req.isAuthenticated()) {
        next();
    } else {
        res.redirect('/');
    }
});

// tell express to serve static files from the /static/secure
// subdirectory as well, but since this middleware function
// is added after the check above, express will never call it
// if the function above doesn't call next()
app.use(express.static(__dirname + '/static/secure'));

// start the server
app.listen(80, function() {
    console.log('server is listening...');
});