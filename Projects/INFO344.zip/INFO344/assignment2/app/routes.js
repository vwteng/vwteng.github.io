var User = require('../app/models/user');

module.exports = function(app, passport) {
    
    // check is user is logged in to go to secure
    app.get('/secure', isLoggedIn, function(req, res) {
        res.redirect('secure.html');
    });
    
    // log the user out
    app.get('/logout', function(req, res) {
       req.logout();
       res.redirect('/');
    });
    
    // use facebook oauth to signin
    app.get('/signin/facebook', passport.authenticate('facebook'));    
    
    // facebook oauth success redirect to secure
    app.get('/signin/facebook/callback', passport.authenticate('facebook'), 
        function(req, res) {
            res.redirect('/secure'); 
    }); 
    
    // api call to signin
    app.post('/api/signin', function(req, res, next) {
        passport.authenticate('local-login', function(err, user, info) {
            if(err) {
                return next(err);
            }
            if(!user) { // send json of the error
                return res.json({error: "Incorrect email or password"});
            }
            req.logIn(user, function(err) {
                if(err) {
                    return next(err);
                } // send json of route to go to next
                return res.json('/secure');
            })
        }) (req, res, next);
    });
    
    // api call to signup
    app.post('/api/signup', function(req, res, next) {
        passport.authenticate('local-signup', function(err, user, info) {
            if(err) { // send json of the error
                return res.json({error: err});
            }
            req.logIn(user, function(err) {
                if(err) {
                    return next(err);
                } // send json of route to go to next
                return res.json('/secure');
            })
        }) (req, res, next);
    });
    
    // api call to update display name
    app.put('/api/updateName', function(req, res) {
        User.findOneAndUpdate({ 'username' :  req.user.username }, { $set: { displayName: req.body.displayName } }, { new: true }, function(err, user) {
            req.logIn(user, function(err) {
                if(err) {
                    return (err);
                }
                return user;
            })
            return res.json(user);
        });
    });
    
    // api call to update password
    app.put('/api/updatePassword', function(req, res) {
        User.findOne({ 'username' :  req.user.username }, function(err, user) {
            // if updating password   
            if (req.body.newPassword.length > 0) {
                // if old password does not match current password, send error
                if(!user.validPassword(req.body.password)) {
                    return res.json({error: "Old password is incorrect"});
                // if new password and confirm password does not match, send error
                } else if(req.body.newPassword != req.body.newPassword2){
                    return res.json({error: "Password confirmation doesn't match password"});
                } else { // user input is valid and new password is saved
                    user.password = user.generateHash(req.body.newPassword);
                    user.save(function(err) {
                        if (err) {
                            throw err;
                        }
                        return user;
                    });
                }
                return res.json(user);
            } else { // user did not provide information to update password 
                return res.json({error: "Enter a new password to change your current password"})
            }
        });
    });
    
    // api call to get current user's information
    app.get('/api/info', function(req, res) {
        res.json(req.user); 
    });
    
    // api call to get hash for gravatar url
    app.get('/api/avatar', function(req, res) {
        var crypto = require('crypto');
        var email = req.user.username;
        var hash = crypto.createHash('md5').update(email).digest('hex');
        res.json(hash); 
    });
};

// check if a user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    } 
    console.log("isLoggedIn = false")
    res.redirect('/');
}