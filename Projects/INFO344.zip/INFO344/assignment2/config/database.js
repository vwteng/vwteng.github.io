var dbConfig = require('.././secret/config-mongo.json');

module.exports = {
    'url' : dbConfig.url
};
