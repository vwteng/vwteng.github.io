var LocalStrategy = require('passport-local').Strategy;
var FacebookStrategy = require('passport-facebook').Strategy;
var passport = require('passport');

// load FacebookStrategy configuration
var fbConfig = require('.././secret/oauth-facebook.json');
// add the callback URL
fbConfig.callbackURL = '/signin/facebook/callback';

// create facebook strategy
var fbStrategy = new FacebookStrategy(fbConfig, 
    function(accessToken, refreshToken, profile, done) {        
        // since different oauth providers may have the same id,
        // fb accounts will have a username of "fb" before the id
        
        // the username in the database is usually an email, but
        // not all fb accounts have an email, so only the id is saved
        // as the username field
        var username = "fb" + profile.id;
        
        // looking in database to see if the fb profile is already stored
        User.findOne({ 'username' :  username }, function(err, user) {
            // if there are any errors, return the error
            if (err) {
                return done(err);
            }
            // if the fb profile is already in the database
            if (user) {
                return done(null, user);
            } else {
                // if fb profile is not in database
                // add fb profile as a new user to the database
                var newUser = new User();

                // set the user's information
                newUser.username = username;
                newUser.displayName = profile.displayName;

                // save the user to database
                newUser.save(function(err) {
                    if (err) {
                        throw err;
                    }
                    return done(null, newUser);
                });   
            }
        });
    });

// use facebook strategy
passport.use(fbStrategy);

var User = require('../app/models/user');

module.exports = function(passport) {
    // used to serialize the user
    passport.serializeUser(function(user, done) {
        done(null, user);
    });

    // used to deserialize the user
    passport.deserializeUser(function(user, done) {
         done(null, user);
    });
    
    // using passport for local signup
    passport.use('local-signup', new LocalStrategy({
        passReqToCallback : true
    },
    function(req, username, password, done) { 
        // looking in database to see if user already exists
        User.findOne({ 'username' :  username }, function(err, user) {
            // if there are any errors, return the error
            if (err) {
                return done(err);
            }
            // if the email is already a user in the database
            if (user) {
                return done("An account already exists with the email address");
            } else { // can attempt to create new user now
                // checking if password & confirm password matches
                
                // password & confirm password does not match
                if (req.body.password != req.body.password2) {
                    return done("Password confirmation doesn't match password");
                } else { // password & confirm password matches
                    // creating new user
                    var newUser = new User();

                    // set the user's information
                    newUser.username = username;
                    newUser.password = newUser.generateHash(password);
                    newUser.displayName = req.body.displayName; 
                    
                    // save the user to database
                    newUser.save(function(err) {
                        if (err) {
                            throw err;
                        }
                        return done(null, newUser);
                    });
                }
            }
        });
    }));
    
    // using passport for local login
    passport.use('local-login', new LocalStrategy({
       passReqToCallback: true 
    },
    function(req, username, password, done) {
        // looking in database to see if the user exists
        User.findOne({ 'username': username}, function(err, user) {
            // if there are any errors, return the error
            if(err) {
                return done(err);
            }
            // user does not exist
            if(!user) {
                return done(err);
            }
            // password for user is incorrect
            if(!user.validPassword(password)) {
                return done(err);
            }
            // successful login
            return done(null, user);
        });
    }));
};