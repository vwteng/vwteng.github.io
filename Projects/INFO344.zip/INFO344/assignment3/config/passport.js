var LocalStrategy = require('passport-local').Strategy;
var passport = require('passport');

var models = require('../app/models/user');

module.exports = function(passport) {
    // used to serialize the user
    passport.serializeUser(function(user, done) {
        done(null, user);
    });

    // used to deserialize the user
    passport.deserializeUser(function(user, done) {
         done(null, user);
    });
    
    // using passport for local signup
    passport.use('local-signup', new LocalStrategy({
        passReqToCallback : true
    },
    function(req, username, password, done) { 
        // looking in database to see if user already exists
        models.User.findOne({ 'username' :  username }, function(err, user) {
            // if there are any errors, return the error
            if (err) {
                return done(err);
            }
            // if the email is already a user in the database
            if (user) {
                return done("An account already exists with the email address");
            } else { // can attempt to create new user now
                // checking if password & confirm password matches
                
                // password & confirm password does not match
                if (req.body.password != req.body.password2) {
                    return done("Password confirmation doesn't match password");
                } else { // password & confirm password matches
                    // creating new user
                    var newUser = new models.User();

                    // set the user's information
                    newUser.username = username;
                    newUser.password = newUser.generateHash(password);
                    newUser.displayName = req.body.displayName; 
                    
                    // create primary account for user
                    var newAccount = new models.Account();
                    newAccount.descriptiveName = "Primary";
                    newAccount.currentBalance = 100;
                    newAccount.save();
                    newUser.account.push(newAccount);
                                     
                    // save the user to database
                    newUser.save(function(err) {
                        if (err) {
                            throw err;
                        }
                        return done(null, newUser);
                    });
                }
            }
        });
    }));
    
    // using passport for local login
    passport.use('local-login', new LocalStrategy({
       passReqToCallback: true 
    },
    function(req, username, password, done) {
        // looking in database to see if the user exists
        models.User.findOne({ 'username': username}, function(err, user) {
            // if there are any errors, return the error
            if(err) {
                return done(err);
            }
            // user does not exist
            if(!user) {
                return done(err);
            }
            // password for user is incorrect
            if(!user.validPassword(password)) {
                return done(err);
            }
            // successful login
            return done(null, user);
        });
    }));
};