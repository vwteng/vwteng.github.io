$(document).ready(function() {
    //  get user's accounts onto page
    $.getJSON('/api/accounts', function(data) {
        for (var i = 0; i < data.length; i++) {   
            $("#account").append("<tr><td>" + data[i]._id + "</td> <td>" + data[i].descriptiveName + "</td> <td>" + data[i].currentBalance + " moon-y</td></tr>");     
            // adds user's accounts to dropdown
            if (i != 0) { // ignores the 1st element because user cannot edit/delete primary account
                $("#accounts").append("<option value=\"" + data[i]._id + "\">" + data[i].descriptiveName + ": " + data[i]._id + "</option>");
            }
        }
    });
    
    // create an account
    $('#addAccountForm').submit(function() {
        // storing user's input data to update
        var descriptiveName = $('input[name=descriptiveName]').val();
        $.ajax({
            type: 'PUT',
            url: '/api/addAccount',
            data: { descriptiveName: descriptiveName },
            success: function(res) {
               
                
                // if there is an error, display the message on page
                if (res.error) {
                    $('#addErrorMessage').html(res.error);
                // successful account update, reload account page
                } else {
                    window.location.href = '/account.html';
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
        });      
       return false;
    });
    
    // change account name
    $('#changeAccountForm').submit(function() {
        // storing user's input data to update
        var currName = $('input[name=currName]').val();
        var newName = $('input[name=newName]').val();
        $.ajax({
            type: 'PUT',
            url: '/api/changeAccount',
            data: { newName: newName, currName: currName },
            success: function(res) {
                // if there is an error, display the message on page
                if (res.error) {
                    $('#changeErrorMessage').html(res.error);
                // successful account update, reload account page
                } else {
                    window.location.href = '/account.html';
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
        });
       return false;
    });
    
    // delete an account
    $('#deleteAccountForm').submit(function() {
        // storing user's input data to update
        var selectedAccount = document.getElementById("accounts");
        var sourceAccount = selectedAccount.options[selectedAccount.selectedIndex].value;
        $.ajax({
            type: 'DELETE',
            url: '/api/deleteAccount',
            data: { sourceAccount: sourceAccount },
            success: function(res) {
                // if there is an error, display the message on page
                if (res.error) {
                    $('#deleteErrorMessage').html(res.error);
                // successful account update, reload account page
                } else {
                    window.location.href = '/account.html';
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
        });
       return false;
    });
});