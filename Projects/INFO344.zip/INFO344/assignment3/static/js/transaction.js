$(document).ready(function() {
    // get total number of transactions to calculate pages
    $.getJSON('/api/transactions', function(data) {
        // total number of pages        
        var pages = Math.ceil(data.length / 20);
        // set up dropdown with page numbers
        for (var i = 0; i < pages; i++) { 
            $("#pages").append("<option value=\"" + (i + 1) + "\"> Page: " + (i + 1) + "</option>");
        }   
                
        // hide transaction table and page drop down if there are not any transactions associated with user
        if(data.length == 0) {
            $("#transactions").hide();
        }
    });
    
    // get initial set of 20 transactions
    $.ajax({
        type: "GET",
        url: "/api/transactionsInitial",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        
        success: function(data) {
            var currUser = data[data.length-1].user;
        data.pop();
        // get data for transactions
        for (var i = 0; i < data.length; i++) {
            var source;
            if (currUser != data[i].userInitiated) {
                source = data[i].userInitiated;
            } else {
                source = data[i].sourceAccount;
            }
            // append transaction information into table
            $("#transaction").append("<tr><td>" + data[i].time + "</td> <td>" + data[i].userInitiated + "</td> <td>" + source + "</td> <td>" + data[i].destinationAccount + "</td> <td>" + data[i].amountTransferred + " Moon-y</td> <td>" + data[i].reason +  "</td></tr>");
        }
        }
    });
        
    // get set of transactions to be displayed
    $('#getSet').submit(function() {
        // storing page user selected
        var selectedPage = document.getElementById("pages");
        var page = selectedPage.options[selectedPage.selectedIndex].value;
        
        $.ajax({
            type: 'PUT',
            url: '/api/transactionsSets',
            data: { page: page },
            success: function(res) {
                $("#transaction").empty();
                
                var currUser = res[res.length-1].user;
                res.pop();
                // get data for transactions
                for (var i = 0; i < res.length; i++) {
                    var source;
                    if (currUser != res[i].userInitiated) {
                        source = res[i].userInitiated;
                    } else {
                        source = res[i].sourceAccount;
                    }
                    // append transaction information into table
                    $("#transaction").append("<tr><td>" + res[i].time + "</td> <td>" + res[i].userInitiated + "</td> <td>" + source + "</td> <td>" + res[i].destinationAccount + "</td> <td>" + res[i].amountTransferred + "</td> <td>" + res[i].reason +  "</td></tr>");
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
        });
       return false;
    });
    
    // get user's accounts to display into a dropdown
    $.getJSON('/api/accounts', function(data) {
        for (var i = 0; i < data.length; i++) { 
            $(".accounts").append("<option value=\"" + data[i]._id + "\">" + data[i].descriptiveName + ": " + data[i]._id + "</option>");
        }
    });
    
    // create a transaction between user's accounts
    $('#addTransactionForm').submit(function() {
        // storing user's input data to add a transaction  
        var selectedSource = document.getElementById("accountsSource");
        var sourceAccount = selectedSource.options[selectedSource.selectedIndex].value;
        var selectedDestination = document.getElementById("accountsDestination");
        var destinationAccount = selectedDestination.options[selectedDestination.selectedIndex].value;
        var amountTransferred = $('input[name=amountTransferred]').val();
        var reason = $('input[name=reason]').val();
        
        $.ajax({
            type: 'POST',
            url: '/api/addTransaction',
            data: { sourceAccount: sourceAccount, destinationAccount: destinationAccount, amountTransferred: amountTransferred, reason: reason },
            success: function(res) {
                if (res.error) { // if there is an error
                    $('#errorMessage').html(res.error);
                // successful transaction, reload transaction page
                } else {
                    window.location.href = '/transaction.html';
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
       });
       return false;
    });
    
    // create a transaction with another user's accounts
    $('#addOtherTransactionForm').submit(function() {
        // storing user's input data to add a transaction  
        var selectedAccount = document.getElementById("accounts");
        var sourceAccount = selectedAccount.options[selectedAccount.selectedIndex].value;
        var destinationAccount = $('input[name=destinationAccount]').val();
        var amountTransferred = $('input[name=amountTransferred]').val();
        var reason = $('input[name=reason]').val();
        
        $.ajax({
            type: 'POST',
            url: '/api/addOtherTransaction',
            data: { sourceAccount: sourceAccount, destinationAccount: destinationAccount, amountTransferred: amountTransferred, reason: reason },
            success: function(res) {
                if (res.error) { // if there is an error
                    $('#errorMessage').html(res.error);
                // successful transaction, reload transaction page
                } else {
                    window.location.href = '/transaction.html';
                }
            },
            error: function(xhr, ajaxOption, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
            }
       });
       return false;
    });
});
