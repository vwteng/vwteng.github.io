var models = require('../app/models/user');

var sgConfig = require('../secret/config-sendgrid.json');

module.exports = function(app, passport) {
    
    // check is user is logged in to go to secure
    app.get('/secure', isLoggedIn, function(req, res) {
        res.redirect('secure.html');
    });
    
    // log the user out
    app.get('/logout', function(req, res) {
       req.logout();
       res.redirect('/');
    });

    // api call to signin
    app.post('/api/signin', function(req, res, next) {
        passport.authenticate('local-login', function(err, user, info) {
            if(err) {
                return next(err);
            }
            if(!user) { // send json of the error
                return res.json({error: "Incorrect email or password"});
            }
            req.logIn(user, function(err) {
                if(err) {
                    return next(err);
                } // send json of route to go to next
                return res.json('/secure');
            })
        }) (req, res, next);
    });
    
    // api call to signup
    app.post('/api/signup', function(req, res, next) {
        passport.authenticate('local-signup', function(err, user, info) {
            if(err) { // send json of the error
                return res.json({error: err});
            }
            req.logIn(user, function(err) {
                if(err) {
                    return next(err);
                } // send json of route to go to next
                return res.json('/secure');
            })
        }) (req, res, next);
    });
    
    // api call to update display name
    app.put('/api/updateName', function(req, res) {
        models.User.findOneAndUpdate({ 'username' :  req.user.username }, { $set: { displayName: req.body.displayName } }, { new: true }, function(err, user) {
            req.logIn(user, function(err) {
                if(err) {
                    return (err);
                }
                return user;
            })
            return res.json(user);
        });
    });
    
    // api call to update password
    app.put('/api/updatePassword', function(req, res) {
        models.User.findOne({ 'username' :  req.user.username }, function(err, user) {
            // if updating password   
            if (req.body.newPassword.length > 0) {
                // if old password does not match current password, send error
                if(!user.validPassword(req.body.password)) {
                    return res.json({error: "Old password is incorrect"});
                // if new password and confirm password does not match, send error
                } else if(req.body.newPassword != req.body.newPassword2){
                    return res.json({error: "Password confirmation doesn't match password"});
                } else { // user input is valid and new password is saved
                    user.password = user.generateHash(req.body.newPassword);
                    user.save(function(err) {
                        if (err) {
                            throw err;
                        }
                        return user;
                    });
                }
                return res.json("Password updated");
            } else { // user did not provide information to update password 
                return res.json({error: "Enter a new password to change your current password"});
            }
        });
    });
    
    // api call to get current user's information
    app.get('/api/info', function(req, res) {
        res.json(req.user); 
    });
    
    // api call to get hash for gravatar url
    app.get('/api/avatar', function(req, res) {
        var crypto = require('crypto');
        var email = req.user.username;
        var hash = crypto.createHash('md5').update(email).digest('hex');
        res.json(hash); 
    });
    
    // api call to get account information associated with current user
    app.get('/api/accounts', function(req, res) {
        models.Account.find({ '_id' : { $in: req.user.account} }, function(err, account) {
            res.json(account);
        });
    });
    
    // api call to add account
    app.put('/api/addAccount', function(req, res) {
        // check if name is blank
        if (req.body.descriptiveName.trim().length === 0) {
            return res.json({error: "Account name cannot be blank"});
        // check if name is greater than 50 characters
        } else if (req.body.descriptiveName.length > 50) {
            return res.json({error: "Account name cannot be longer than 50 characters long"});
        // check if name is primary
        } else if (req.body.descriptiveName.toLowerCase() == "primary") {
            return res.json({error: "Account name cannot be named 'Primary'"});
        }
        // find the user to get information about accounts
        models.User.findOne({ 'username' :  req.user.username }, function(err, user) {
            // check how many accounts user has to see if they can make another account
            if (user.account.length == 5) { // cannot add another account
                res.json({error: "You cannot have more than 5 accounts"}); // this should send a status
            } else { // create new account
                var newAccount = new models.Account();
                newAccount.descriptiveName = req.body.descriptiveName;
                newAccount.currentBalance = 0;
                newAccount.save();
                // add new account to user
                user.account.push(newAccount);   
                user.save();
                                           
                req.logIn(user, function(err) {
                    if(err) {
                        return (err);
                    }
                    return user;
                })
                return res.json(newAccount);
            }
        });
    });
    
    // api call to change account name
    app.put('/api/changeAccount', function(req, res) {
        // check if name is blank
        if (req.body.newName.trim().length === 0) {
            return res.json({error: "Account name cannot be blank"});
        // check if name is greater than 50 characters
        } else if (req.body.newName.length > 50) {
            return res.json({error: "Account name cannot be longer than 50 characters long"});
        // check if name is primary
        } else if (req.body.newName.toLowerCase() == "primary") {
            return res.json({error: "Account name cannot be named 'Primary'"});
        // check if account being changed is the primary account
        } else if (req.body.currName.toLowerCase() == "primary") {
            return res.json({error: "Primary account name cannot be changed"});
        }
        // find the account to update the name
        models.Account.findOneAndUpdate({ 'descriptiveName' : req.body.currName }, { $set: { descriptiveName: req.body.newName } }, { new: true }, function(err, account) {
            res.json(account);
        });
    });
    
    // api call to delete account
    app.delete('/api/deleteAccount', function(req, res) {
        // check if account being deleted is the primary account
        if (req.body.sourceAccount.toLowerCase() == "primary") {
            return res.json({error: "Primary account name cannot be deleted"});
        }
        // find the account to be deleted
        models.Account.findOne({ '_id' : req.body.sourceAccount }, function (err, account) {
           // check if the balance is 0
            if(account.currentBalance > 0) {
                res.json({error: "Account has a balance greater than zero and cannot be deleted"}); // this should send a status
            } else {        
                models.User.findOne({ 'username' : req.user.username }, function (err, user) {
                    var accIndex = user.account.indexOf(req.body.sourceAccount);
                    // check if account belongs to user and is not primary
                    if (accIndex <= 0) {
                        return res.json({error: "Account cannot be deleted"}); // this should send a satus
                    }
                    user.account.splice(accIndex, 1);
                    user.save();
                });
                // delete the account
                account.remove();
                account.save();
                res.json("Account deleted");
           }
       });
    });
    
    // api call to get transactions information associated with current user
    app.get('/api/transactions', function(req, res) {
        // find transactions where current user either transferred or received money
        models.Transaction.find( { $or: [ { 'userInitiated' : req.user.username }, {'destinationAccount' : req.user.username } ] }, function(err, transaction) {
            res.json(transaction);
        });
    });
    
     // api call to get initial set of transactions
    app.get('/api/transactionsInitial', function(req, res) {
        // find transactions where current user either transferred or received money
        models.Transaction.find( { $or: [ { 'userInitiated' : req.user.username }, {'destinationAccount' : req.user.username } ] }, function(err, transaction) {
            transaction.push({'user' : req.user.username});
            res.json(transaction);
        }).limit(20).sort({'time': -1}); // limit to first 20 
    });
    
    // api call to get set of transactions at a time
    app.put('/api/transactionsSets', function(req, res) {
        // find transactions where current user either transferred or received money
        models.Transaction.find( { $or: [ { 'userInitiated' : req.user.username }, {'destinationAccount' : req.user.username } ] }, function(err, transaction) {
            transaction.push({'user' : req.user.username});
            res.json(transaction);
        }).limit(20).skip(20 * (req.body.page -1)).sort({'time': -1}); // get additional sets of 20
    });
    
    // api call to add transaction to one self
    app.post('/api/addTransaction', function(req, res) {
        // check if source account belongs to user
        models.User.findOne({ 'username' : req.user.username}, function(err, user) {
            // check if user has source account
            if (user.account.indexOf(req.body.sourceAccount) > -1) {
                // check if destination account exists
                if (user.account.indexOf(req.body.destinationAccount) > -1) {         
                    // check if source account has enough money
                    models.Account.findOne({ '_id' : req.body.sourceAccount }, function(err, account) {
                        // check if source account has enough money
                        if (account.currentBalance < req.body.amountTransferred) {
                            res.json({error: "There isn't enough money in source account to be transferred"});
                        } else {
                            // remove money from source account
                            account.currentBalance -= req.body.amountTransferred;
                            account.save();
                            // add money to destination account
                            models.Account.findOneAndUpdate({ '_id' : req.body.destinationAccount }, { $inc: { currentBalance:  req.body.amountTransferred } }, function(err, account) {});
                            
                            // send email to notify money was transferred
                            var sendgrid = require("sendgrid")(sgConfig.key);
                            var email = new sendgrid.Email();

                            email.addTo(req.user.username);
                            email.setFrom("test@email.com");
                            email.setSubject("A Transaction Was Made");
                            email.setHtml("Money was transferred between your accounts");

                            sendgrid.send(email);
                            
                            // create transaction
                            var newTransaction = new models.Transaction();
                            newTransaction.sourceAccount = req.body.sourceAccount;
                            newTransaction.destinationAccount = req.body.destinationAccount;
                            newTransaction.amountTransferred = req.body.amountTransferred;
                            newTransaction.userInitiated = req.user.username;
                            newTransaction.reason = req.body.reason;
                            newTransaction.save();
                            return res.json(newTransaction);
                        } 
                    });        
                } else {
                    res.json({error: "Destination account does not belong to you"});
                }
            } else {
                res.json({error: "Source account does not belong to you"});
            }    
        });     
    });

    // api call to add transaction to another account
    app.post('/api/addOtherTransaction', function(req, res) {
        // check if source account belongs to user
        models.User.findOne({ 'username' : req.user.username }, function(err, user) {
            // check if user has source account
            if (user.account.indexOf(req.body.sourceAccount) > -1) {
                // check if destination account exists
                models.User.findOne( { 'username' : req.body.destinationAccount }, function(err, user) {
                    if(!user) {
                       res.json({error: "Destination account does not exist"});
                    } else { // account does exist
                       // check if source account has enough money
                        models.Account.findOne({ '_id' : req.body.sourceAccount }, function(err, account) {
                            if (account.currentBalance < req.body.amountTransferred) {
                                res.json({error: "There isn't enough money in source account to be transferred"});
                            } else {
                                // send email to source account user that transaction was made
                                var sendgrid = require("sendgrid")(sgConfig.key);
                                var email = new sendgrid.Email();

                                email.addTo(req.user.username);
                                email.setFrom("test@email.com");
                                email.setSubject("A Transaction Was Made");
                                email.setHtml("Money was transferred from your account to another user");

                                sendgrid.send(email);
                                
                                // send email to destination account user that transaction was made
                                var email2 = new sendgrid.Email();

                                email2.addTo(user.username);
                                email2.setFrom("test@email.com");
                                email2.setSubject("A Transaction Was Made");
                                email2.setHtml("Money was transferred to your account from another user");

                                sendgrid.send(email2);
                                
                                // there is enough money, so we need to remove it form source account
                                account.currentBalance -= req.body.amountTransferred;
                                account.save();            
                                // get destination user's primary account to add money to
                                models.Account.findOneAndUpdate({ '_id' : user.account[0] }, { $inc: { currentBalance: req.body.amountTransferred } }, function(err, account) {});
                                // create transaction record
                                var newTransaction = new models.Transaction();
                                newTransaction.sourceAccount = req.body.sourceAccount;
                                newTransaction.destinationAccount = req.body.destinationAccount;
                                newTransaction.amountTransferred = req.body.amountTransferred;
                                newTransaction.userInitiated = req.user.username;
                                newTransaction.reason = req.body.reason;
                                newTransaction.save();
                                return res.json(newTransaction);
                            }
                        });
                    }
                });
            } else {
                res.json({error: "Source account does not belong to you"});
            }       
        });     
    });
};

// check if a user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    } 
    console.log("isLoggedIn = false")
    res.redirect('/');
}