var mongoose = require('mongoose');
var bcrypt = require('bcrypt');

// schemas for mongodb
var userSchema = mongoose.Schema({
        username: String,
        password: String,
        displayName: String,
        account: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Account'}] // array of account object id
});

var accountSchema = mongoose.Schema({
        descriptiveName: String,
        currentBalance: Number
});

var transactionSchema = mongoose.Schema({
        sourceAccount: String,
        destinationAccount: String,
        amountTransferred: Number,
        time: {type: Date, default: Date.now},
        userInitiated: String,
        reason: String
});

// salt and hash password
userSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// check if password is valid
userSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};

// create the model with user, account and transaction
var models = {
    User: mongoose.model('User', userSchema),
    Account: mongoose.model('Account', accountSchema),
    Transaction: mongoose.model('Transaction', transactionSchema)
};

module.exports = models;