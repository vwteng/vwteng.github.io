'use strict';

var should = require('should');
var request = require('request-promise');
var mongoose = require('mongoose');

// var server = require('../server.js');

var host = process.env.HOST || '127.0.0.1';
var baseUrl = 'http://' + host + '/api';

var configDB = require('../config/database.js');
var dbConfig = require('../secret/config-mongo.json');
mongoose.connect(dbConfig.url);

var models = require('../app/models/user.js');

// information for first user
var j = request.jar();
var testUser = 'user@test.com';
var account = 'test account';
var accountId;

// information for second user
// SECOND USER MUST ALREADY EXIST IN DATABASE           //
// SECOND USER MUST ALREADY HAVE 5 ACCOUNTS ASSOCIATED  //
// ACCOUNT ID MUST BE SET TO EXISITING IN DATABASE      //
var j2 = request.jar();
var dataUser = 'testdata@test.com';
var dataPrimaryId = '56cd59206285fea716f78e55';
var dataAccountId = '56cd59236285fea716f78e56';

describe('Create User API', function() {
    it('should create a new user', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/signup',
            body: { username: testUser, password: 'test', password2: 'test', displayName: 'test'},
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.should.be.equal('/secure');
            });
    });
    
    it('should error that passwords do not match', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/signup',
            body: { username: 'test2@test.test', password: 'te1st', password2: 'test', displayName: 'test name'},
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Password confirmation doesn\'t match password");
            });
    });
    
    it('should error that user already exists', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/signup',
            body: { username: testUser, password: 'test', password2: 'test', displayName: 'test name'},
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("An account already exists with the email address");
            });
    });
});

describe('Sign In API', function() {    
    it('should error that the credentials are incorrect', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/signin',
            body: { username: testUser, password: 'wrong' },
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Incorrect email or password");
            });
    });
    
    it('should sign user in', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/signin',
            body: { username: testUser, password: 'test' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.should.be.equal('/secure');
            });
    });
    
    it('should sign data user in', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/signin',
            body: { username: dataUser, password: 'test' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.should.be.equal('/secure');
            });
    });
});

describe('Update Profile Display Name API', function() {  
    it('should update display name', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/updateName',
            body: { username: testUser, displayName: 'test2' },
            jar: j,
            json: true
        };

        return request(option)
            .then(function(body) {
                body.displayName.should.be.equal('test2');
            });
    });
});

describe('Update Profile Password API', function() {  
    it('should update password', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/updatePassword',
            body: { username: testUser, password: 'test', newPassword: 'test2', newPassword2: 'test2', displayName: 'test' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.should.be.equal("Password updated");
            });
    });
    
    it('should error that current password does not match credentials', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/updatePassword',
            body: { username: testUser, password: 'wrong', newPassword: 'test', newPassword2: 'test', displayName: 'test' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Old password is incorrect");
            });
    });
    
    it('should error that the new passwords do not match', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/updatePassword',
            body: { username: testUser, password: 'test2', newPassword: 'wrong', newPassword2: 'test', displayName: 'test' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Password confirmation doesn't match password");
            });
    });
});

describe('Add Account API', function() {  
    it('should error that name cannot be default', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/addAccount',
            body: { descriptiveName: 'Primary' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account name cannot be named 'Primary'");
            });
    });
    
    it('should error that name cannot be blank', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/addAccount',
            body: { descriptiveName: '      ' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account name cannot be blank");
            });
    });
    
    it('should error that name cannot be more than 50 characters long', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/addAccount',
            body: { descriptiveName: 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz' },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account name cannot be longer than 50 characters long");
            });
    });
    
    it('should add new account', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/addAccount',
            body: { descriptiveName: account },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                accountId = body._id;
                body.descriptiveName.should.be.equal.account;
            });
    });
    
    it('should error that user cannot have more than 5 accounts', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/addAccount',
            body: { descriptiveName: 'another account' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("You cannot have more than 5 accounts");
            });
    });
});

describe('Change Account API', function() {  
    it('should error that name cannot be default', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/changeAccount',
            body: { newName: 'Primary', currName: account },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account name cannot be named 'Primary'");
            });
    });
    
    it('should error that name cannot be blank', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/changeAccount',
            body: { newName: '      ', currName: account },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account name cannot be blank");
            });
    });
    
    it('should error that name cannot be more than 50 characters long', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/changeAccount',
            body: { newName: 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz', currName: account },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account name cannot be longer than 50 characters long");
            });
    });
    
    it('should change account name', function() {
        var option = {
            method: 'PUT',
            uri: baseUrl + '/changeAccount',
            body: { newName: 'new name', currName: account },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.descriptiveName.should.be.equal('new name');
            });
    });
});

describe('Delete Account API', function() {  
    it('should error that account balance cannot be greater than 0', function() {
        var option = {
            method: 'DELETE',
            uri: baseUrl + '/deleteAccount',
            body: { sourceAccount: dataAccountId },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Account has a balance greater than zero and cannot be deleted");
            });
    });
    
    it('should delete the account', function() {
        var option = {
            method: 'DELETE',
            uri: baseUrl + '/deleteAccount',
            body: { sourceAccount: accountId },
            jar: j,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.should.be.equal("Account deleted");
            });
    });
});

describe('Add Transaction With Self API', function() {  
    it('should error that source account does not have enough balance', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addTransaction',
            body: { sourceAccount: dataPrimaryId, destinationAccount: dataAccountId, amountTransferred: '1000', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("There isn't enough money in source account to be transferred");
            });
    });
    
    it('should error that source account does not belong to user', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addTransaction',
            body: { sourceAccount: 'fake', destinationAccount: dataAccountId, amountTransferred: '1000', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Source account does not belong to you");
            });
    });
    
    it('should error that destination account does not belong to user', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addTransaction',
            body: { sourceAccount: dataPrimaryId, destinationAccount: 'fake', amountTransferred: '1000', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Destination account does not belong to you");
            });
    });
    
    it('should transfer money from one account to another account owned by user', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addTransaction',
            body: { sourceAccount: dataPrimaryId, destinationAccount: dataAccountId, amountTransferred: '5', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body._id.should.exist;
            });
    });
});

describe('Add Transaction With Other User API', function() {  
    it('should error that source account does not have enough balance', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addOtherTransaction',
            body: { sourceAccount: dataPrimaryId, destinationAccount: testUser, amountTransferred: '1000', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("There isn't enough money in source account to be transferred");
            });
    });
    
    it('should error that source account does not belong to user', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addOtherTransaction',
            body: { sourceAccount: 'fake', destinationAccount: testUser, amountTransferred: '1000', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Source account does not belong to you");
            });
    });
    
    it('should error that destination user account does not exist', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addOtherTransaction',
            body: { sourceAccount: dataPrimaryId, destinationAccount: 'fake', amountTransferred: '1000', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body.error.should.be.equal("Destination account does not exist");
            });
    });
    
    it('should transfer money from one account to another account owned by user', function() {
        var option = {
            method: 'POST',
            uri: baseUrl + '/addOtherTransaction',
            body: { sourceAccount: dataPrimaryId, destinationAccount: testUser, amountTransferred: '5', reason: 'because of reasons' },
            jar: j2,
            json: true
        };
        
        return request(option)
            .then(function(body) {
                body._id.should.exist;
            });
    });
});

describe('Revert Changes', function() {
    it('should delete the initial user created', function() {
       models.User.findOne({username: testUser}).remove(function(user,err){});
    });
    
    it('should reset data user to have money', function() {
       models.Account.findOneAndUpdate({ '_id' : dataPrimaryId }, { $inc: { currentBalance:  10 } }, function(err, account) {});
    });
});
