<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);

require 'vendor/autoload.php';

use Parse\ParseClient;

// Fixes "The session id is too long or contains illegal characters" error
$ok = @session_start();
if(!$ok){
	session_regenerate_id(true); // replace the Session ID
	session_start(); 
}

ParseClient::initialize('11DguEZb7ojRE5vFn7n24P6UbYNXRHBtxO9RcEPs',
												'j2yXtpc0yAuPbuVlGoR88q9H3o5HN4wtBk07WUMU',
												'gSvmh9aIoEmLoI7OyrpTGGTpcf5jL0NfPQaIxWgv');

?>
