<?php
// Preps the data to be displayed in the dashboard

require_once('session.php');
include('claimClass.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;
use Parse\ParseException;

$currentUser = ParseUser::getCurrentUser();

$claimQuery = new ParseQuery("Claim");

if($currentUser) {
	$claimQuery->equalTo("user", $currentUser->getObjectId());
	$claims = $claimQuery->find();

	foreach($claims as $claim) {
		$dropsiteQuery = new ParseQuery("Dropsite");
		$dropsiteId = $claim->get("dropsiteId");
		try {
          $dropsite = $dropsiteQuery->get($dropsiteId);

          $claimDetail[] = new Claim($dropsite->get("organization"), $dropsite->get("address1"), $dropsite->get("address2"), $dropsite->getUpdatedAt(), $dropsiteId, $dropsite->get("name"), $claim->get("status"));
          $userClaims['details'] = $claimDetail;
        } catch (ParseException $ex) {
          // The object was not retrieved successfully.
          // error is a ParseException with an error code and message.
        }
    }

   	if(isset($userClaims)) {
      echo json_encode($userClaims); 
    }    
}
?>