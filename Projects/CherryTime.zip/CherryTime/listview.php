<?php require_once('session.php'); ?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
	    <title>CherryTime</title>
	    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
	    <meta name="description" content="Make time for charity.">
	    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
	    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	    <link rel="stylesheet" type="text/css" href="css/styles.css">
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	</head>
	<body>
		<header>
			<?php include 'header.php'; ?>
			<br>
			<input type="text" id="cause-filter" class="search" placeholder="Cause">
			<a href="/" class="icon"><i class="fa fa-globe fa-4x"></i><br><b>Map View</b></a>
			<a href="#" id="filter-btn" class="icon"><i class="fa fa-filter fa-4x"></i><br><b>Filter</b></div></a>
			<a href="adddropsite.php" class="icon"><i class="fa fa-plus fa-4x"></i><br><b>Add Dropsite</b></a>
			<div id="filter-options-list">
        <div class="filter-option">
          <input type="text" id="item-category-filter" placeholder="Item category">
        </div>
        <div class="filter-option">
          <input type="text" id="organization-filter" placeholder="Organization">
				</div>
			</div>
		</header>

		<div class="container">
			<div class="list">
				<div class="locations">
					<!-- location cards go here -->
				</div>
			</div>
		</div>

		<div class="location template" onclick="details(this)">
			<div class="top-loc">
				<span class="organization"></span>
			</div>
			<br>
			<div class="availability"></div>
			<div class="causes"></div>
			<div class="address"></div>
			<p class="idSite" style="display: none"></p>

		</div>
	</body>
	<script src="https://maps.googleapis.com/maps/api/js?libraries=places"></script>
	<script type="text/javascript" src="js/listsearch.js"></script>
	<script type="text/javascript" src="js/listview.js"></script>
	<script type="text/javascript" src="js/filter.js"></script>
</html>
