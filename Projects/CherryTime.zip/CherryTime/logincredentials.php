<?php
require_once('session.php');

use Parse\ParseUser;
use Parse\ParseException;

if(isset($_POST["email"]) && isset($_POST["password"])) {
    try {
		$user = ParseUser::logIn($_POST["email"], $_POST["password"]);
    } catch (ParseException $error) {
    	echo "Your email or password was incorrect";	
    }
}
?>
