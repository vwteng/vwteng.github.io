$(document).ready(function() {
  Parse.initialize("11DguEZb7ojRE5vFn7n24P6UbYNXRHBtxO9RcEPs",
                   "NEtv7sg5s9RsWHTNwgwT5e6Z1d7jnB9hUmztiIpv");
  var dropsite = Parse.Object.extend("Dropsite");

  $('#filter-btn').click(function () {
    if ($('#filter-options-list').is(':hidden')) {
      $('#filter-options-list').slideDown();
      updateFilter();
    } else {
      $('#filter-options-list').slideUp();
      unfilter();
    }
  });

  function updateFilter() {
    // make sure the filter only applies when the filter options are shown
    if ($('#filter-options-list').is(':hidden') && $('#cause-filter').val() == null) {
      unfilter();
    } else {
      // get filter values and apply to Parse query
      var causeFilter = $('#cause-filter').val();
      var itemCategoryFilter = $('#item-category-filter').val();
      var organizationFilter = $('#organization-filter').val();

      var query = new Parse.Query(dropsite);
      if (causeFilter.length > 0) {
        query.contains("cause", causeFilter);
      }
      if (itemCategoryFilter.length > 0) {
        query.contains("categories", itemCategoryFilter);
      }
      if (organizationFilter.length > 0) {
        query.contains("organization", organizationFilter);
      }

      getDropsites(query);
    }
  }

  // reset the results shown so that there is no filtering
  function unfilter() {
    var query = new Parse.Query(dropsite);
    getDropsites(query);
  }

  // Listen for any changes to the filter options and update the filter
  $('.filter-option').keyup(function(e) {
    updateFilter();
  });

  $('#cause-filter').keyup(function(e) {
    updateFilter();
  });
});
