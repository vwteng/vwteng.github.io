var map;
Parse.initialize("11DguEZb7ojRE5vFn7n24P6UbYNXRHBtxO9RcEPs", "NEtv7sg5s9RsWHTNwgwT5e6Z1d7jnB9hUmztiIpv");
var markers = [];
var mc;
var previnfobox;

// Builds the map using a set of map options and gets the initial set of
// dropsites to add to the map.
// TODO: get user's current location and set that as the center
// TODO: add a button to get the user's current location/re-center
function initialize() {
  var mapOptions = {
    center: new google.maps.LatLng(47.6097, -122.3331), // default = Seattle
    zoom: 13,
    streetViewControl: false,
    zoomControl:true,
    zoomControlOptions:{
      style:google.maps.ZoomControlStyle.SMALL,
      position:google.maps.ControlPosition.LEFT_CENTER
    },
    panControl:true,
    panControlOptions:{
      position:google.maps.ControlPosition.LEFT_CENTER
    },
    // styles from https://snazzymaps.com/
    styles: [{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#e0efef"}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"hue":"#1900ff"},{"color":"#c0e8e8"}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"visibility":"off"},{"lightness":700}]},{"featureType":"transit.line","elementType":"labels","stylers":[{"visibility":"off"},{"lightness":700}]},{"featureType":"transit.line","elementType":"labels","stylers":[{"visibility":"off"},{"lightness":700}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#b2d0ff"}]}]
  };

  var dropsite = Parse.Object.extend("Dropsite");
  var query = new Parse.Query(dropsite);

  getDropsites(query)

  map = new google.maps.Map($('#map-canvas').get(0), mapOptions);

  askToUseLocation();
}

function getDropsites(query) {
  query.find({
    success: function(results) {
      console.log("Successfully retrieved " + results.length);

      if(mc != null) {
        mc.clearMarkers();
        markers = [];
      }

      for (var i = 0; i < results.length; i++) {
        var object = results[i];
        var info = buildInfobox(object);

        // We store the dropsites' lat/long pair in the Parse Core because we
        // are limited to looking up 10 lat/long pairs using Google Maps API.
        var lat = object.get('lat');
        var lng = object.get('lng');
        if(lat == null || lng == null) {
          console.log("new Geocoder request");
          latlngarray = getLatLng(object);
        } else {
          var latLng = new google.maps.LatLng(lat, lng);
          var marker = addMarker(latLng, info);

          markers.push(marker);
        }
      }
      var mcOptions = {gridSize: 50, maxZoom: 13,
        styles: [{
          url: '/img/pin-01.png',
          height: 44,
          width: 30,
          anchor: [7, 0],
          textColor: 'white',
          textSize: 15,
          maxZoom: 0

        }]
      };

      mc = new MarkerClusterer(map, markers, mcOptions);
    },
    error: function(error) {
      status.error("Error: " + error.code + " " + error.message);
    }
  });
}

function askToUseLocation() {
  if(navigator.geolocation) {
    console.log("trying to determine user's location.");
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = new google.maps.LatLng(position.coords.latitude,
                                       position.coords.longitude);
      console.log(pos);
      map.setCenter(pos);
    }, function() {
      console.log("Could not determine user's location.");
    });
  }
}

function clearMarkers() {
  mc.clearMarkers();
}

// Unpackage the dropsite fields and return a string representation of an
// infobox div to be rendered in the infobox.
function buildInfobox(object) {
  var info = '';
  info += '<div id="infobox" onclick="details(\'' + object.id + '\')">';
  info += '   <span class="organization-map"> <h2>' + object.get('organization') + '</h2> </span>';
  info += '   <div class="availability-map"> <p class="open-map"> Open </p>' + object.get('availability') + '</div>';
  info += '   </br>';
  info += '   <div class="causes-map"> Causes: ' + object.get('cause') + '</div>';
  info += '   </br>';
  info += '   <div class="address-map">' + object.get('address1') + "<br>" + object.get('address2') + '</div>';
  info += '   <p class="idSite" style="display: none"></p>';
  info += '</div>';

  return info
}

function details(id) {
  window.location = "viewdropsite.php?id=" + id;
}

// Store the lat/lng pair in the Core so we don't have to spend precious API
// calls on it anymore!
function saveLatLng(object, lat, lng) {
  object.save(null, {
    success: function(object) {
      object.set("lat", lat);
      object.set("lng", lng);
      object.save();
    }
  });
}

// Make an API call to Google to retrieve the lat/lng pair. Return the pair as
// an array.
function getLatLng(object) {
  var address = object.get('address1') + ' ' + object.get('address2');
  var geocoder = new google.maps.Geocoder();

  geocoder.geocode({
      'address': address
  }, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        var lat = results[0].geometry.location.lat();
        var lng = results[0].geometry.location.lng();
        var latLng = new google.maps.LatLng(lat, lng);
        saveLatLng(object, lat, lng);
      } else {
        Console.log("Unable to get Lat/Lng pair from Google!");
      }
  });
}

// Create the infobox & marker objects and add them to the map.
function addMarker(latLng, info) {
  var infobox = new InfoBox({
    content: info,
    closeBoxURL: ""   // hides the close box
  });

  var marker = new google.maps.Marker({
    position: latLng,
    center: latLng,
    map: map,
    icon: "img/pins-01.png"
  });

  google.maps.event.addListener(marker, 'click', function() {
    map.setCenter(latLng);
    if(previnfobox != null) {
      previnfobox.close();
    }

    if(previnfobox == infobox) {
      infobox.close();
      previnfobox = null;
    } else {
      infobox.open(map, marker);
      previnfobox = infobox;
    }

  });

  return marker;
}

google.maps.event.addDomListener(window, 'load', initialize);

