// code originally from https://developers.google.com/maps/documentation/javascript/examples/places-searchbox

function initializeSearchBox() {

  // Create the search box and link it to the UI element.
  var input = document.getElementById('search');
  var searchBox = new google.maps.places.SearchBox(input);

  // Bias the query suggestions to locations within the map bounds
  searchBox.setBounds(map.getBounds());

  // Listen for the event fired when the user selects an item from the
  // pick list. Center the map on the new matched place.
  google.maps.event.addListener(searchBox, 'places_changed', function() {
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    map.setCenter(places[0].geometry.location);
    searchBox.setBounds(map.getBounds());
  });
}

google.maps.event.addDomListener(window, 'load', initializeSearchBox);
