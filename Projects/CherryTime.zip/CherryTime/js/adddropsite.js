Parse.initialize("11DguEZb7ojRE5vFn7n24P6UbYNXRHBtxO9RcEPs", "NEtv7sg5s9RsWHTNwgwT5e6Z1d7jnB9hUmztiIpv");

// When the user clicks Submit, add the dropsite to the db
$("#addDropsiteForm").submit(function addDropsite() {

  // create new subclass
  var Dropsite = Parse.Object.extend("Dropsite");

  // create new instance OF that subclass
  // note: style-wise, Parse uses CapitalizedFirstLetters for subclasses
  //       and camelCase for instances of subclasses.
  var dropsite = new Dropsite();

  // save to db
  dropsite.save({
    name: $("#inpName").val(),
    organization: $("#inpOrganization").val(),
    cause: $("#inpCause").val(),
    categories: $("#inpCategories").val(),
    address1: $("#inpAddress1").val(),
    address2: $("#inpAddress2").val(),
    availability: $("#inpAvailability").val(),
    requirements: $("#inpRequirements").val()
  }, {
    success: function(dropsite) {
      // successful save
      alert("whoohoo!");
      // user should be redirected to the dropsite page now
    },
    error: function(dropsite, error) {
      // the save failed, output error message
      alert(error.message);
    }
  });

  return false;

});
