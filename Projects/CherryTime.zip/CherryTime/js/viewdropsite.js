Parse.initialize("11DguEZb7ojRE5vFn7n24P6UbYNXRHBtxO9RcEPs", "NEtv7sg5s9RsWHTNwgwT5e6Z1d7jnB9hUmztiIpv");

function render_map(address) {
  var geocoder = new google.maps.Geocoder();
  var latLng;
  var marker;
  var map;

  var mapOptions = {
      zoom: 12,
      streetViewControl: false,
      scrollwheel: false,
      navigationControl: false,
      styles: [{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#e0efef"}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"hue":"#1900ff"},{"color":"#c0e8e8"}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"visibility":"off"},{"lightness":700}]},{"featureType":"transit.line","elementType":"labels","stylers":[{"visibility":"off"},{"lightness":700}]},{"featureType":"transit.line","elementType":"labels","stylers":[{"visibility":"off"},{"lightness":700}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#b2d0ff"}]}]
  };

  map = new google.maps.Map(document.getElementById('dropsite-map'), mapOptions);

  geocoder.geocode({
      'address': address
  }, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
          var latitude = results[0].geometry.location.lat();
          var longitude = results[0].geometry.location.lng();
          latLng = new google.maps.LatLng(latitude, longitude);

          marker = new google.maps.Marker({
              position: latLng,
              center: latLng,
              map: map,
              icon: "img/pins-01.png"
          });

          map.setCenter(latLng);
      }
  });

  google.maps.event.addDomListener(window, 'resize', function() {
      map.setCenter(marker.getPosition());
  });
}
