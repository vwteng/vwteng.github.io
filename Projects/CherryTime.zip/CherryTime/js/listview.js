$(document).ready(function() {
  Parse.initialize("11DguEZb7ojRE5vFn7n24P6UbYNXRHBtxO9RcEPs",
                   "NEtv7sg5s9RsWHTNwgwT5e6Z1d7jnB9hUmztiIpv");
 var dropsite = Parse.Object.extend("Dropsite");
 var query = new Parse.Query(dropsite);
 getDropsites(query);
});

function getDropsites(query) {
  query.find({
    success: function(results) {
      console.log("Successfully retrieved " + results.length);

      var template = $('.location.template');
      var container = $('.locations');

      container.empty();

      for (var i = 0; i < results.length; i++) {
        var instance =  template.clone();
        var object = results[i];
        instance = buildCard(object, instance);
        container.append(instance);
      }
    },
    error: function(error) {
      status.error("Error: " + error.code + " " + error.message);
      console.log(error);
    }
  });
}

function buildCard(object, instance) {
  var causes = object.get('cause');
  var address = object.get('address1');
  var address2 = object.get('address2');
  var availability = object.get('availability');
  var organization = object.get('organization');
  var site = object.get('name');
  var id = object.id;

  var link = document.createElement("a");
  link.setAttribute("href", "/viewdropsite.php?id=" + id);

  //Appends to the template
  instance.find('.organization').html("<h2>" + organization + "</h2> <i>" + site + "</i>");
  instance.find('.causes').html('<img src="img/causes/' + causes + '.png">' + causes);

  if (availability == "Always open") {
    instance.find('.availability').html('<p class="open">Open</p>' + availability);
  } else {
    instance.find('.availability').html(availability);
  }
  instance.find('.idSite').html(id);
  instance.find('.address').html('<img src="img/pins-01.png"/>' + "<br>" + address + "<br>" + address2);
  instance.removeClass('template');

  return instance;
}

function details(elem) {
  window.location = "/viewdropsite.php?id=" + elem.getElementsByTagName('p')[1].innerHTML;
}
