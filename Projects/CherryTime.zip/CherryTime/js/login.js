$(document).ready(function(){
  $("#passwordMessage").on("click", function () {
    $("#forgotPassword").show();
    $("#passwordMessage").hide();
  });

  $("#submitReset").on("click", function () {
    $.ajax({
      type: "POST",
      url: "passwordreset.php",
      data: { userEmail: $("#emailReset").val() },
      success: function(data){
        $("#resetMessage").html(data);
        $("#resetMessage").addClass("alert");
      }
    });
  });

  $("#submitLogin").on("click", function () {
    $.ajax({
      type: "POST",
      url: "logincredentials.php",
      data: { email: $("#emailAddress").val(), password: $("#password").val()  },
      success: function(data){
        $("#errorMessage").html(data);
        $("#errorMessage").addClass("alert");
      }
    });
  });

});