$(document).ready(function(){
    var dropsiteId = $('#dropsite-id').text();
    $('#claim-button').click(function(){
		$.ajax({
			type: "POST",
			dataType: 'text',
			data: { id: dropsiteId },
			url: "claim.php",
			success: function(data){
				console.log(data);
				if(data === "successful") {
					$("#claim-success").append("A member of our team will review your claim request shortly, check your dashboard for updates");
				} else {
					$("#claim-success").append("You already claimed this dropsite!");
				}
			}
		});
	});
});