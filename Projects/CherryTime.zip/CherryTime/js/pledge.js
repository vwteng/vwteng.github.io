$(document).ready(function(){
    $('#pledge-button').click(function(){
        var dropsiteId = $('#dropsite-id').text();
        $.post('pledge.php', { id: dropsiteId }, function (response) {
            $('#pledge-success').html(response);
            location.reload();
        });
    });
});
