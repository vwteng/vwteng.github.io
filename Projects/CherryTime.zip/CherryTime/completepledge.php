<?php
// Finds the users pledge of the dropsite and marks the status as complete

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;

$dropsiteId = $_POST["dropsiteId"];

$pledgeQuery = new ParseQuery("Pledge");

$currentUser = ParseUser::getCurrentUser();
$pledgeQuery->equalTo("userId", $currentUser->getObjectId());
$pledgeQuery->equalTo("dropsiteId", $dropsiteId);
$pledges = $pledgeQuery->find();

// Marks Pledge As Complete
foreach($pledges as $pledge) {
	echo $pledge->get("status");
	$pledge->set("status", "completed");
	$pledge->save();
}
?>