<?php

// Finds the users pledge of the dropsite and marks the status as complete

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;
use Parse\ParseObject;
use Parse\ParseException;

$dropsiteId = $_POST["id"];

$claim = new ParseObject("Claim");

$currentUser = ParseUser::getCurrentUser();
if($currentUser) {
	if(!claimExists($currentUser, $dropsiteId) && !claimed($dropsiteId)) {
		$claim->set("dropsiteId", $dropsiteId);
		$claim->set("user", $currentUser->getObjectId());
		$claim->set("status", 1);

		try {
	     $claim->save();
	      	echo("successful");
	    } catch (ParseException $e) {
	        echo("failure");
	    }

		$msg = "User: " . $currentUser->getObjectId() . " would like to claim the dropsite: " . $dropsiteId ."\nPlease Verify";

		$subject = "Claim request for dropsite: " . $dropsiteId; 

		mail("contact@cherryti.me",$subject,$msg);

	} else {
		echo "Already exists";
	}
}

// Check if there is already a claim for this dropsite by this user - prevents duplicates
function claimExists($currentUser, $dropsiteId) {
    $claimQuery = new ParseQuery("Claim");
    $claimQuery->equalTo("user", $currentUser->getObjectId());
    $claimQuery->equalTo("dropsiteId", $dropsiteId);
    $claims = $claimQuery->find();

    if(count($claims) > 0) {
      return true;
    } else { 
      return false; 
    }
}

// Checks if the dropsite is already claimed
function claimed($dropsiteId) {
	$claimQuery = new ParseQuery("Claim");
    $claimQuery->equalTo("dropsiteId", $dropsiteId);
    $claims = $claimQuery->find();

    foreach($claims as $claim) {
    	if($claim->get("status") !== 1) {
    		return true;
    	}
    }
}
?>