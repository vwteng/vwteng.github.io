<?php require_once('session.php'); ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>

  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>
    <!-- Form for Individual registration -->
    <div class="container">
      <h1>About Us</h1>
      <p class="dropsite-address" style="line-height: 120%">Everyone has something they can donate to charity, but many do not have the time. Existing applications that aim to make charity convenient have focused on monetary donations while neglecting physical donations. Non-profit organizations need physical items that many individuals own, but do not use. CherryTime is a web application that seeks to enable anyone with limited time to donate physical items. With CherryTime, donations take minutes. Users can find nearby donation sites, give to charity, and continue their day. The list of sites is community-provided and community-maintained. Non-profit organizations can specify exactly what they need and monitor the health of their donation sites. CherryTime gives users a lens into the needs of their community and gives them the power to make a difference. </p>

      <iframe style="border: 2px solid black" width="560" height="315" src="https://www.youtube.com/embed/ubhhHYesc6E?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
      <img style="width: 30%; border: 2px solid black" src="/img/poster.png">
    <div class="us">
      <h1>Meet the developers</h1>
      <div class="person">
        <h3>Mariam Davis</h3>
        <a href="mailto:mh94@uw.edu">mh97@uw.edu</a>
        <br>
        <a href="https://www.linkedin.com/in/mariamdavis">LinkedIn</a>
      </div>

      <div class="person">
        <h3>Cam Scotland</h3>
        <a href="mailto:scotlc@uw.edu">scotlc@uw.edu</a>
        <br>
        <a href="https://www.linkedin.com/in/camscotland">LinkedIn</a>
      </div>

      <div class="person">
        <h3>Vivian Teng</h3>
        <a href="mailto:vwteng@uw.edu">vwteng@uw.edu</a>
        <br>
        <a href="https://www.linkedin.com/in/vivianwteng">LinkedIn</a>
      </div>

      <div class="person">
        <h3>Brandon Thai</h3>
        <a href="mailto:bthaib@gmail.com">bthaib@gmail.com</a>
        <br>
        <a href="https://www.linkedin.com/in/brandonthai">LinkedIn</a>
      </div>
<br><br>
      <img style="width: 20%" src="/img/team.jpg">
    </div>

  </body>
</html>
