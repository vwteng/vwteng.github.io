<?php 
// Grabs the current favorite status of a dropsite

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;

$dropsiteId = $_POST['id'];

$favoriteQuery = new ParseQuery("Favorites");

$currentUser = ParseUser::getCurrentUser();
if($currentUser) {
	$favoriteQuery->equalTo("userId", $currentUser->getObjectId());
	$favoriteQuery->equalTo("dropsiteId", $dropsiteId);
	$favorite = $favoriteQuery->find();

	if(count($favorite) > 0) {
		echo "exists";
	}
}
?>