<?php 
// Gets the request details of the site

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;
use Parse\ParseException;

$dropsiteId = $_POST["id"];


$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {
	$dropsiteQuery = new ParseQuery("Dropsite");
    $dropsiteQuery->equalTo("objectId", $dropsiteId);
    $dropsites = $dropsiteQuery->find();

    $details = []; 

    foreach($dropsites as $dropsite) {
    	$details[] = $dropsite->get("name"); 
    	$details[] = $dropsite->get("organization");
    	$details[] = $dropsite->get("address1");
    	$details[] = $dropsite->get("address2");
    	$details[] = $dropsite->get("categories");
    	$details[] = $dropsite->get("requirements");
    }

    echo json_encode($details);
}   
?>