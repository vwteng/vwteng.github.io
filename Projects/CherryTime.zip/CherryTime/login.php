<?php
require_once('session.php');

use Parse\ParseUser;

$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {
  isset($_SESSION['destination'])? header($_SESSION['destination']): header('Location: index.php');
}
?>

<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/login.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>
  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>

    <div class="container">
      <h1>Account Sign in</h1>
      <form>
        <input class="form" type="email" id="emailAddress" placeholder="Enter email" pattern="(?!(^[.-].*|[^@]*[.-]@|.*\.{2,}.*)|^.{254}.)([a-zA-Z0-9!#$%&'*+\/=?^_`{|}~.-]+@)(?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}" name="email" required autofocus>
        <input class="form" type="password"  id="password" placeholder="Enter Password" name="password" required>
        <p id="errorMessage"></p>
        <input class="navbut" type="submit" id="submitLogin" style="float: right" value="Login" formmethod="POST" />
      </form>
      <p id="passwordMessage"><u>Forgot your password?</u></p>
      <a href="signup.php"><p id="passwordMessage"><u>Need an account?</u></p></a>
      <div id="forgotPassword" style="display:none">
        <p id="info">Enter your email below to receive your login information</p>
        <input type="email" class="form" style="width:50%" id="emailReset" placeholder="Enter email" name="forgotPassword" pattern="(?!(^[.-].*|[^@]*[.-]@|.*\.{2,}.*)|^.{254}.)([a-zA-Z0-9!#$%&'*+\/=?^_`{|}~.-]+@)(?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}">
        <input type="submit" class="navbut" id="submitReset" value="Reset My Password">
        <p id="resetMessage"></p>
      </div>
    </div>
  </body>
</html>
