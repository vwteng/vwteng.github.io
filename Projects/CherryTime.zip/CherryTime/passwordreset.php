<?php
require_once('session.php');

use Parse\ParseUser;
use Parse\ParseException;

if(isset($_POST["userEmail"])) {
	$userEmail = $_POST["userEmail"];
	try {
	  ParseUser::requestPasswordReset($userEmail);
	    // Password reset request was sent successfully
	  	echo "Please check your email for password reset instructions!";
	} catch (ParseException $ex) {
		// Password reset failed, check the exception message
		echo "The email you entered is not present in our database. Please try again!";
	}
} else {
	echo "Not hit";
}
?>