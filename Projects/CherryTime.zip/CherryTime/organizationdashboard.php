<?php
require_once('session.php');

use Parse\ParseUser;
use Parse\ParseException;

$currentUser = ParseUser::getCurrentUser();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" href="css/styles.css" />
    <link rel="stylesheet" type="text/css" href="css/dashboard.css" />

  </head>
  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>

    <div id="loading"></div>

    <div class="container">
      <h2><?php echo $currentUser->get("name") . " Dropsites" ?></h2>
      <table class="table">
        <thead>
          <tr>
            <th>Address</th>
            <th>Site Status<th>
          </tr>
        </thead>
        <tbody id="claimColumn">
        </tbody>
      </table>
      <div id="editBox" style="display:none">
        <p class="head">Organization:</p>
        <textarea rows="4" cols="50" id="name" ></textarea>
        <p class="head">Address 1:</p>
        <textarea rows="4" cols="50" id="address1" ></textarea>
        <p class="head">Address 2:</p>
        <textarea rows="4" cols="50" id="address2" ></textarea>
        <p class="head">Categories (Things Needed):</p>
        <textarea rows="4" cols="50" id="categories" ></textarea>
        <p class="head">Requirements:</p>
        <textarea rows="4" cols="50" id="requirements" ></textarea>
        <p id="siteId" style="display:none"></p>

        <button id="cancel">Cancel</button>
        <button id="submit">Save</button>
      </div>
      <p id="successEdit"></p>
    </div>
  </body>
</html>

<script>
  $(document).ajaxStart(function () {
      $('#loading').show();  // show loading indicator
      $('.container').hide();
  });

  $(document).ajaxStop(function () {
      $('#loading').hide();  // show loading indicator
      $('.container').show();
  });

  $( document ).ready(function() {
    $.ajax({
      type: "POST",
      dataType: 'text',
      url: "claimData.php",
      success: function(data){
        console.log(data);

        if(data) {
          data = $.parseJSON(data);
          for(i = 0; i < data.details.length; i++) {
            var status; 
            if(data.details[i].Status === 1) {
                status = "Pending Approval";
            } else if(data.details[i].Status === 2) {
                status = "<input type='button' class='dropsite-navbut' name=" + data.details[i].Id + " value='Edit' onclick='editSite(this)'>";
            } else if(data.details[i].Status === 3) {
                status === "Not Approved";
            }

            var siteProfile = "<a href='/viewdropsite.php?id=" + data.details[i].Id + "'>" + data.details[i].Address1 + " " + data.details[i].Address2 + "</a>";

                
            $("#claimColumn").append("<tr><td>" + siteProfile + "</td> <td>" + status + "</td> </tr>");
          }
        }
      }
    });

    $("#cancel").click(function (){
      $("#editBox").hide();
    });

    $("#submit").click(function (){
      $.ajax({
        type: "POST",
        dataType: 'text',
        data: { 
          orgName: $("#name").val(), 
          siteName: $("#siteName").val(),
          address1: $("#address1").val(),
          address2: $("#address2").val(),
          categories: $("#categories").val(),
          requirements: $("#requirements").val(), 
          id: $("#siteId").text() 
        },
        url: "updateSite.php",
        success: function(data){
          console.log(data);
          if(data === "success") {
            $("#editBox").hide();

            $("#successEdit").append("Successfully saved");
          }
        }
      });
    });
  });

  function editSite(elem) {
    var id = elem.getAttribute("name");
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { id: id },
      url: "getSiteDetails.php",
      success: function(data){
      data = $.parseJSON(data);
        var organizationEdit;
        var siteNameEdit;
        var adresss1Edit;
        var adresss2Edit;
        var categoriesEdit;
        var requirementsEdit;

        for(var i = 0; i < data.length; i++) {
          organizationEdit = data[0];
          siteNameEdit = data[1];
          address1Edit = data[2];
          address2Edit = data[3];
          categoriesEdit = data[4];
          requirementsEdit = data[5];
        }

        $("#name").empty();
        $("#siteName").empty();
        $("#address1").empty();
        $("#address2").empty();
        $("#categories").empty();
        $("#siteId").empty();
        $("#requirements").empty();
        $("#successEdit").empty();

        $("#name").append(organizationEdit);
        $("#siteName").append(siteNameEdit);
        $("#address1").append(address1Edit);
        $("#address2").append(address2Edit);
        $("#categories").append(categoriesEdit);
        $("#siteId").append(id);
        $("#requirements").append(requirementsEdit);

        $("#editBox").show();
      }
    });
  }
</script>