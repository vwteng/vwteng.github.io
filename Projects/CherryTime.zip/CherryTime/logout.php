<?php
require_once('session.php');

use Parse\ParseUser;

if(ParseUser::getCurrentUser()) {
	ParseUser::logOut();
	session_destroy();
}

header("Location: index.php");
?>
