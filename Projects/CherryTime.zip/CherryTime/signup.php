<?php require_once('session.php'); ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>

  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>
    <!-- Form for Individual registration -->
    <div class="container">
      <h1>Register as an:</h1>
      <br>
      <form id="submitForm">
        <input class="navbut" style="text-align: center; font-size: 120%; width: auto" name="account" value="Individual" onclick="window.location='/signupindividual.php'"></input>
        <br><br>
        <input class="navbut" style="text-align: center; font-size: 120%; width: auto" name="account" value="Organization" onclick="window.location='/signuporganization.php'"></input>
        <br>
      </form>
    </div>
  </body>
</html>
