<?php 
require_once('session.php');
use Parse\ParseUser;
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseException;


$dropsiteId = $_POST['id'];

$currentUser = ParseUser::getCurrentUser();
if($currentUser) {
	if(!favoriteExists($currentUser, $dropsiteId)) {
		$favorite = new ParseObject("Favorites");
		$favorite->set("userId", $currentUser->getObjectId());
		$favorite->set("dropsiteId", $dropsiteId);

		try {
			$favorite->save();
		    echo("successfully favorited!");
		} catch (ParseException $e) {
			echo("failed to favorite. Please try again.");
		}
	}	
}

// Check if user already has dropsite favorited
function favoriteExists($currentUser, $dropsiteId) {
    $favoriteQuery = new ParseQuery("Favorites");
    $favoriteQuery->equalTo("userId", $currentUser->getObjectId());
    $favoriteQuery->equalTo("dropsiteId", $dropsiteId);
    $favorites = $favoriteQuery->find();

    if(count($favorites) > 0) {
      return true;
    } else { 
      return false; 
    }
}
?>