<?php
// Updates the dropsite with user's input

require_once('session.php');

use Parse\ParseQuery;
use Parse\ParseUser;
use Parse\ParseObject;
use Parse\ParseException;

$dropsiteId = $_POST["id"];

$dropsiteQuery = new ParseQuery("Dropsite");
$dropsiteQuery->equalTo("objectId", $dropsiteId);
$dropsites = $dropsiteQuery->find();

foreach($dropsites as $dropsite) {
	$dropsite->set("address1", $_POST["address1"]);
	$dropsite->set("address2", $_POST["address2"]);
	$dropsite->set("organization", $_POST["orgName"]);
	$dropsite->set("name", $_POST["siteName"]);
	$dropsite->set("categories", $_POST["categories"]);
	$dropsite->set("requirements", $_POST["requirements"]);
	$dropsite->save();
	echo "success";
}
?>