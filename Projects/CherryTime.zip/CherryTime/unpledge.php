<?php
// Finds the users pledge of the dropsite and removes it from the pledge table 

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;

$dropsiteId = $_POST["dropsiteId"]; 


$pledgeQuery = new ParseQuery("Pledge");

$currentUser = ParseUser::getCurrentUser();
$pledgeQuery->equalTo("userId", $currentUser->getObjectId());
$pledgeQuery->equalTo("dropsiteId", $dropsiteId);
$pledges = $pledgeQuery->find();

// Removes pledge from pledge table
foreach($pledges as $pledge) {
	$pledge->destroy();
}
?>