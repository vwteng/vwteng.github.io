<?php 
// Gets the users current pledges and pledge history to be displayed on the individual dashboard

header('Content-type: application/json');

require_once('session.php');
include('siteClass.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;


// If the user is logged in, retrieve their pledges and badges. If they aren't
// logged in, redirect them to the login page.
$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {

    // Get all pledges for the logged-in user
    $pledgeQuery = new ParseQuery("Pledge");
    $pledgeQuery->equalTo("userId", $currentUser->getObjectId());
    $pledges = $pledgeQuery->find();

    // Get all badges for the logged-in user
    /* NOTE: badges are not in the Core yet...
    $badgeQuery = new ParseQuery("Badge");
    $badgeQuery->equalTo("userId", $currentUser->getObjectId());
    $badges = $pledgeQuery->find();
    */
    foreach ($pledges as $pledge) {
      // Render the pledges
      if($pledge->get("status") != "completed") {
        $dropsiteQuery = new ParseQuery("Dropsite");
        $dropsiteId = $pledge->get("dropsiteId");
        try {
          $dropsite = $dropsiteQuery->get($dropsiteId);

          $userpledges[] = new site($dropsite->get("organization"), $dropsite->get("address1"), $dropsite->get("address2"), $pledge->getCreatedAt(), $dropsiteId, null, $dropsite->get("name"));
          $pledgeList['pledges'] = $userpledges;
        } catch (ParseException $ex) {
          // The object was not retrieved successfully.
          // error is a ParseException with an error code and message.
        }
      } else if($pledge->get("status") === "completed") {
        $dropsiteQuery = new ParseQuery("Dropsite");
        $dropsiteId = $pledge->get("dropsiteId");
        try {
          $dropsite = $dropsiteQuery->get($dropsiteId);

          $userHistory[] = new site($dropsite->get("organization"), $dropsite->get("address1"), $dropsite->get("address2"), $pledge->getCreatedAt(), $dropsiteId, $pledge->getUpdatedAt(), $dropsite->get("name"));
          $pledgeList['history'] = $userHistory;
        } catch (ParseException $ex) {
          // The object was not retrieved successfully.
          // error is a ParseException with an error code and message.
        }
      }
    }

    // Get all favorites for the logged-in user 
    $favoriteQuery = new ParseQuery("Favorites");
    $favoriteQuery->equalTo("userId", $currentUser->getObjectId());
    $favorites= $favoriteQuery->find();

    foreach($favorites as $favorite) {
      $dropsiteQuery = new ParseQuery("Dropsite");
      $dropsiteId = $favorite->get("dropsiteId");
      try {
        $dropsite = $dropsiteQuery->get($dropsiteId);

        $userFavorites[] = new site($dropsite->get("organization"), $dropsite->get("address1"), $dropsite->get("address2"), null, $dropsiteId, null, $dropsite->get("name"));
        $pledgeList['favorites'] = $userFavorites;
      } catch (ParseException $ex) {
        // The object was not retrieved successfully.
        // error is a ParseException with an error code and message.
      }
    }
    if(isset($pledgeList)) {
      echo json_encode($pledgeList); 
    }
} else {
    header("Location: login.php");
}
// Render these things on this page:
// - Pledges which are upcoming
// - Badges! 'CHIEVES!!!11
// - History of past pledges
?>