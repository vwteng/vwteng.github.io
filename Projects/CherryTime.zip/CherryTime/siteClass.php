<?php
// Object Class for a donation site

	class site {
		public $Name, $Address1, $Address2, $Date, $Id, $CompleteDate, $Sitename;

		public function __construct($Name, $Address1, $Address2, $Date, $Id, $CompleteDate, $Sitename) {
			$this->Name = $Name;
			$this->Address1 = $Address1;
			$this->Address2 = $Address2;
			$this->Date = $Date;
			$this->Id = $Id;
			$this->CompleteDate = $CompleteDate;
			$this->Sitename = $Sitename;
		}
	}
?>