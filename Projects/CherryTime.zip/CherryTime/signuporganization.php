<?php
require_once('session.php');
use Parse\ParseUser;
use Parse\ParseException;
use Parse\ParseFile;
use Parse\ParseObject;

$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {
  header('Location: index.php');
}
?>

<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>

  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>  
    <!-- Form for organization registration -->
    <div class="container">
      <h1>Organization registration</h1>
      <form id="submitForm" method="post" enctype="multipart/form-data">

        <label for="orgName"></label>
        <input class="form" type="text" id="orgName" placeholder="Enter organization name" name="orgName" required autofocus>

        <label for="email"></label>
        <input class="form" type="email" id="email" placeholder="Enter email" name="email" pattern="(?!(^[.-].*|[^@]*[.-]@|.*\.{2,}.*)|^.{254}.)([a-zA-Z0-9!#$%&'*+\/=?^_`{|}~.-]+@)(?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}" required>

        <label for="password"></label>
        <input class="form" type="password"  id="password" placeholder="Enter password" oninput="isMatch()" name="password" required>

        <label for="confirm_password"></label>
        <input class="form" type="password"  id="confirm_password" placeholder="Confirm password" oninput="isMatch()" name="confirm_password" required>
        <p id="errorMessage"></p>

        <label for="address1"></label>
        <!-- Street address, P.O. box, company name, c/o  -->
        <input class="form" type="text"  id="address1" placeholder="Address line 1" name="address1" required>

        <label for="address2"></label>
        <!-- Apartment, suite, unit, building, floor, etc. -->
        <input class="form" type="text" id="address2" placeholder="Address line 2" name="address2">

        <label for="cityName"></label>
        <!-- Apartment, suite, unit, building, floor, etc. -->
        <input class="form" type="text" id="cityName" placeholder="City, State, Zip" name="cityName" required>

        <label for="phoneNum"></label>
        <input class="form" type="tel" id="phoneNum" placeholder="Enter phone number" pattern="\d{3}[\-]\d{3}[\-]\d{4}" name="phone">

        <label for="website"></label>
        <input class="form" type="url" id="website" maxLength="2048" placeholder="Enter website link (optional)" pattern="https?:\/\/(?![^\/]{253}[^\/])((?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}|((1[0-9]{2}|[1-9]?[0-9]|2([0-4][0-9]|5[0-5]))\.){3}(1[0-9]{2}|[1-9]?[0-9]|2([0-4][0-9]|5[0-5])))(\/.*)?" name="website">

        <label for="fileselect"><span style="display: block; color: white">Upload Logo (PNG or JPG only)</label><br>
        <input class="form" type="file" name="image" id="fileselect" name="logo">

        <input class="navbut" style="float: right" type="submit" value="Register">
     </form>
        <a href="signup.php"><button class="navbut">Cancel</button></a>
   </div>
  </body>

  <script>
    function isMatch() {
      if($("#confirm_password").val().length == 0 && $("#password").val().length == 0) {
          $("#errorMessage").empty();
          $("#errorMessage").removeClass("alert");
      } else {
        if($("#confirm_password").val() != $("#password").val()) {
          $("#errorMessage").html("Passwords Do Not Match");
          $("#errorMessage").addClass("alert");
          return false;
        } else {
          $("#errorMessage").html("Passwords Match");
          $("#errorMessage").addClass("alert");
          return true;
        }
      }
    }
  </script>
</html>

<?php
  function passwordConfirmed() {
    return $_POST["password"] === $_POST["confirm_password"];
  }
  if(isset($_POST["email"], $_POST["password"], $_POST["orgName"], $_POST["address1"], $_POST["cityName"])) {
    if(passwordConfirmed()) {
      try {
          $user = new ParseUser();
          $user->set("username", $_POST["email"]);
          $user->set("password", $_POST["password"]);
          $user->set("email", $_POST["email"]);
          $user->set("name", $_POST["orgName"]);
          $user->set("address1", $_POST["address1"]);
          $user->set("address2", $_POST["address2"]);
          $user->set("city", $_POST["cityName"]);
          $user->set("phone", $_POST["phone"]);
          $user->set("website", $_POST["website"]);
          $user->set("userType", 2);

          if (!empty($_FILES['image']['name'])) {
            // Save file to Parse
            $file = ParseFile::createFromData(file_get_contents( $_FILES['image']['tmp_name']), $_FILES['image']['name']);
            $file->save();
            // Save file to our ImageObject
            $image = ParseObject::create("ImageObject");
            $image->set( "foo", "bar" );
            // add the file we saved above
            $image->set( "image", $file );
            $image->save();
            // Gets the file url and stores it to the organization user
            $user->set("logo", $file->getURL());
          }
          $user->signUp();
?>
          <script> window.location.replace("index.php"); </script>

<?php        
      } catch (ParseException $ex) {
        // Show the error message somewhere and let the user try again.
        echo "Error: " . $ex->getCode() . " " . $ex->getMessage();
      }
    } else {
      echo "Please confirm your password to match";
    }
  }
