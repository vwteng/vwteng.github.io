<?php
echo('<a href="/index.php"><img class="logo" src="img/logo.png"></a>');

use Parse\ParseUser;

$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {
	echo("<ul>");
	echo('<li style="color: #c6db58">Hello ' . $currentUser->get("name") . "</li>");
	if($currentUser->get("userType") === 1) { // 1 is an individual
		echo('<li><a href="individualdashboard.php">View Dashboard</a></li>');
	} else {
		echo('<li><a href="organizationdashboard.php">View Dashboard</a></li>');
	}
  echo('<li><a href="logout.php" name="submit">Logout</a></li>');
	echo("</ul>");
} else {
	echo("<ul>");
	echo('<li><a href="/login.php">Login</a></li>');
  echo('<li><a href="signup.php">Register</a></li>');
	echo("</ul>");
}
