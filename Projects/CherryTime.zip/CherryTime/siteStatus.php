<?php 
// Grabs the current pledge status of a dropsite
// If user isn't logged in the button will display 'Login to Start Pledging'

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;

$dropsiteId = $_POST['id'];

$pledgeQuery = new ParseQuery("Pledge");

$currentUser = ParseUser::getCurrentUser();
if($currentUser) {
	$pledgeQuery->equalTo("userId", $currentUser->getObjectId());
	$pledgeQuery->equalTo("dropsiteId", $dropsiteId);
	$pledgeQuery->notEqualTo("status", "completed");
	$pledges = $pledgeQuery->find();

	foreach($pledges as $pledge) {
		echo $pledge->get("status");
	}
} else {
	echo "Login to Start Pledging";
}
?>