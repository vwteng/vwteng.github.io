<?php
// Object Class for a claim

	class Claim {
		public $Name, $Address1, $Address2, $Update, $Id, $Sitename, $Status;

		public function __construct($Name, $Address1, $Address2, $Update, $Id, $Sitename, $Status) {
			$this->Name = $Name;
			$this->Address1 = $Address1;
			$this->Address2 = $Address2;
			$this->Update = $Update;
			$this->Id = $Id;
			$this->Sitename = $Sitename;
			$this->Status = $Status;
		}
	}
?>