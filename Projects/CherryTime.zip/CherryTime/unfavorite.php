<?php
// Finds the user's favorite of the dropsite and removes it from the favorite table 

require_once('session.php');

use Parse\ParseClient;
use Parse\ParseQuery;
use Parse\ParseUser;

$dropsiteId = $_POST["dropsiteId"]; 

$favoriteQuery = new ParseQuery("Favorites");

$currentUser = ParseUser::getCurrentUser();
$favoriteQuery->equalTo("userId", $currentUser->getObjectId());
$favoriteQuery->equalTo("dropsiteId", $dropsiteId);
$favorites = $favoriteQuery->find();

// Removes favorite from pledge table
foreach($favorites as $favorite) {
	$favorite->destroy();
}
?>