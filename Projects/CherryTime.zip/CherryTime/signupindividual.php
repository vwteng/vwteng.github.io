<?php
require_once('session.php');

use Parse\ParseUser;
use Parse\ParseException;

$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {
  header('Location: index.php');
}
?>

<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>

  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>  
    <!-- Form for Individual registration -->
    <div class="container">
      <h1>Individual registration</h1>
      <form id="submitForm" method="post">

        <label for="name"></label>
        <input class="form" type="text" id="name" placeholder="Enter name" name="name" required autofocus>

        <label for="email"></label>
        <input class="form" type="email"  id="email" placeholder="Enter email" name="email" pattern="(?!(^[.-].*|[^@]*[.-]@|.*\.{2,}.*)|^.{254}.)([a-zA-Z0-9!#$%&'*+\/=?^_`{|}~.-]+@)(?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}" required>

        <label for="password"></label>
        <input class="form" type="password"  id="password" placeholder="Enter password" oninput="isMatch()" name="password" required>

        <label for="confirm_password"></label>
        <input class="form" type="password"  id="confirm_password" placeholder="Confirm password" oninput="isMatch()" name="confirm_password" required>
        <p id="errorMessage"></p>
        <input class="navbut" style="float: right" type="submit" value="Register">

      </form>
      <a href="signup.php"><button class="navbut">&#8592;Back</button></a>
    </div>
  </body>

  <script>
    function isMatch() {

      if($("#confirm_password").val().length == 0 && $("#password").val().length == 0) {
          $("#errorMessage").empty();
          $("#errorMessage").removeClass("alert");
      } else {
        if($("#confirm_password").val() != $("#password").val()) {
          $("#errorMessage").html("Passwords Do Not Match");
          $("#errorMessage").addClass("alert");
          return false;
        } else {
          $("#errorMessage").html("Passwords Match");
          $("#errorMessage").addClass("alert");
          return true;
        }
      }
    }
  </script>
</html>
<?php
  // Makes sure user confirms password correctly before trying to create an account
  function passwordConfirmed() {
    return ($_POST["password"] === $_POST["confirm_password"]);
  }

  if(isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["name"])) {
    if(passwordConfirmed()) {
      try {
        $user = new ParseUser();
        $user->set("username", $_POST["email"]);
        $user->set("password", $_POST["password"]);
        $user->set("email", $_POST["email"]);
        $user->set("name", $_POST["name"]);
        $user->set("userType", 1);
        $user->signUp();
?>
       <script> window.location.replace("index.php"); </script>
<?php
        exit;
        //echo "You have successfully signed up";
      } catch (ParseException $ex) {
        // Show the error message somewhere and let the user try again.
        echo $ex->getMessage();
      }
    } else {
        echo "Please confirm your password to match";
    }
  }
?>
