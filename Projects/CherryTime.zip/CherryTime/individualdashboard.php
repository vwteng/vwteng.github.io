<?php
require_once('session.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css" />
    <link rel="stylesheet" type="text/css" href="css/dashboard.css" />

  </head>
  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>

    <div id="loading"></div>

    <div class="container">
      <h2>Pledges</h2>
      <table class="table">
        <thead>
          <tr>
            <th>Organization</th>
            <th>Days Since Pledge</th>
          </tr>
        </thead>
        <tbody id="pledgeColumn">
        </tbody>
      </table>
      <h2>History</h2>
      <table class="table">
      <thead>
        <tr>
          <th>Organization</th>
          <th style="text-align: right">Pledge Completion Date</th>
        </tr>
      </thead>
      <tbody id="historyColumn">
      </tbody>
    </table>
    <h2>Favorites</h2>
     <table class="table">
      <thead>
        <tr>
          <th>Organization</th>
          <th></th>
        </tr>
      </thead>
      <tbody id="favoritesColumn">
      </tbody>
    </table>
    </div>
  </body>
</html>

<script>
  $(document).ajaxStart(function () {
        $('#loading').show();  // show loading indicator
        $('.container').hide();
    });

  $(document).ajaxStop(function () {
        $('#loading').hide();  // show loading indicator
        $('.container').show();
    });

  $(document).ready(function(){
    $.ajax({
      type: "POST",
      dataType: 'text',
      url: "dashboarddata.php",
      success: function(data){
        if(data) {
          data = $.parseJSON(data);
          if(data.pledges !== undefined) {  // check if user have pledges currently
            for(i = 0; i < data.pledges.length; i++) {
              var getDate = data.pledges[i].Date.date;
              var formatedDate = (getDate + " ").split(" ")[0]; // Formats to YEAR-MM-DY
              var date1 = new Date(formatedDate);
              var date2 = new Date(getTodaysDate());

              var pledgeDate = getDiffDays(date1, date2); // Gets number of days since pledge
              if(pledgeDate === 1) {
                pledgeDate = "Today";
              } else {
                pledgeDate = pledgeDate + " days ago";
              }

              var unpledgeButton = "<input type='button'  class='dashboard-navbut' name=" + data.pledges[i].Id + " value='Unpledge' onclick='unpledgeSite(this)'>";
              var completeButton = "<input type='button'  class='dashboard-navbut' name=" + data.pledges[i].Id + " value='Completed' onclick='pledgedSite(this)'>";

              $("#pledgeColumn").append("<tr><td>" + data.pledges[i].Name + "</td> <td>" +  pledgeDate + "</td><td>" + unpledgeButton + completeButton + "</td></tr>");
            }
          }

          if(data.history !== undefined) { // check if user has a history of pledges 
            for(j = 0; j < data.history.length; j++) {
              var getDate = data.history[j].CompleteDate.date;
              var formatedDate = (getDate+" ").split(" ")[0];
              $("#historyColumn").append("<tr><td>" + data.history[j].Name + "</td><td class='pDate'>" + formatedDate + "</td></tr>");
            }
          }

          if(data.favorites !== undefined) {
            for(k = 0; k < data.favorites.length; k++) {
              var siteProfile = "<a href='/viewdropsite.php?id=" + data.favorites[k].Id + "'>" + data.favorites[k].Name + "</a>";
              var removeButton = "<input type='button'  class='dashboard-navbut' name=" + data.favorites[k].Id + " value='Unfavorite' onclick='unfavorite(this)'>";
              $("#favoritesColumn").append("<tr><td>" + siteProfile + "</td><td>" + removeButton +  "</td></tr>");
            }
          } 
        }
      }    
    });

    // Gets the current date 
    function getTodaysDate() {
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth()+1; //January is 0!
      var yyyy = today.getFullYear();
      if(dd<10) {
          dd='0'+dd
      } 
      if(mm<10) {
          mm='0'+mm
      } 
      return today = mm+'/'+dd+'/'+yyyy;
    }

    // Gets the difference in days of two dates 
    function getDiffDays(a, b) {
      var _MS_PER_DAY = 1000 * 60 * 60 * 24;

      var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
      var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

      return Math.floor((utc2 - utc1) / _MS_PER_DAY);
    }
  });

  // Removes pledge from user's dashboard and pledge table
  function unpledgeSite(elem) {
    var id = elem.getAttribute("name"); // Gets dropsite id
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { dropsiteId: id },
      url: "unpledge.php",
      success: function(data){
        // Reload page to remove pledge from user view 
        location.reload();
      }
    });
  } 

  // Changes status of pledge to complete 
  function pledgedSite(elem) {
    var id = elem.getAttribute("name");
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { dropsiteId: id },
      url: "completepledge.php",
      success: function(data){
        // Reload page to remove pledge from pledge table view to history table view
        location.reload();
      }
    });
  }

  function unfavorite(elem) {
    var id = elem.getAttribute("name");
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { dropsiteId: id },
      url: "unfavorite.php",
      success: function(data){
        // Reload page to remove favorite table
        location.reload();
      }
    });
  }
</script>