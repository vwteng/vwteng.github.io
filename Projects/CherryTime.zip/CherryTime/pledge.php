<?php
require_once('session.php');
use Parse\ParseUser;
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseException;

$dropsiteId = $_POST['id'];
$currentUser = ParseUser::getCurrentUser();
if ($currentUser) {

    if(!pledgeExists($currentUser, $dropsiteId) ) {
      // do stuff with the user
      $pledge = new ParseObject("Pledge");
      $pledge->set("userId", $currentUser->getObjectId());
      $pledge->set("dropsiteId", $dropsiteId);
      $pledge->set("status", "Pending");

      try {
        $pledge->save();
        echo("successfully saved your pledge!");
      } catch (ParseException $e) {
        echo("failed to save your pledge. Please try again.");
      }
    }
} else {
    // show the signup or login page
    echo('failure');
}

// Check if the user has a pending pledge to this specific site
function pledgeExists($currentUser, $dropsiteId) {
    $pledgeQuery = new ParseQuery("Pledge");
    $pledgeQuery->equalTo("userId", $currentUser->getObjectId());
    $pledgeQuery->equalTo("dropsiteId", $dropsiteId);
    $pledgeQuery->notEqualTo("status", "completed");
    $pledges = $pledgeQuery->find();

    if(count($pledges) > 0) {
      return true;
    } else { 
      return false; 
    }
}