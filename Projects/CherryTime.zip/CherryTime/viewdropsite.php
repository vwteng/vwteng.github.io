<?php
require_once('session.php');

use Parse\ParseQuery;
use Parse\ParseException;
use Parse\ParseUser;

$currentUser = ParseUser::getCurrentUser();

# Retrieve the dropsite's ID from the GET query param. If we can't find
# the param, set $dropsiteId to NULL.
# TODO: Update this to use POST in the future when other pages
#       link to it.
# TODO: What if the user gets to this page but doesn't have a query param?
#       Perhaps we ought to have some redirect behavior when it's NULL.
$dropsiteId = isset($_GET['id'])? $_GET['id'] : NULL;
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <script type="text/javascript" src="js/pledge.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?libraries=places"></script>
    <script type="text/javascript" src="js/viewdropsite.js"></script>
    <script type="text/javascript" src="js/claim.js"></script>
    <link rel="stylesheet" type="text/css" href="css/viewdropsite.css" />
    <link rel="stylesheet" type="text/css" href="css/styles.css" />
  </head>

  <body class="responsive">
    <header>
      <?php include 'header.php'; ?>
    </header>

    <div class="container" id="dropsite">
      <?php
      # Create a new Query object to grab data from the Dropsite table
      $query = new ParseQuery("Dropsite");

      # Encapsulate this in a try/catch block to avoid nasty Parse errors
      try {
        $dropsite = $query->get($dropsiteId);

        # success! Print the sweet, sweet details of the dropsite
        echo('<div class="block">');
        echo('  <img src="img/charrity.jpg" alt="sample icon" class="pull-left dropsite-icon"/>');
        echo('  <h1 style="color: #55c3be">' . $dropsite->get('organization') . '</h1>');
        echo('  <h2>' . $dropsite->get('name') . '</h2>');
        echo('  <p class="label cause" style="font-size: 90%; margin-bottom: 10px">' . "Cause: " . $dropsite->get('cause') . '</p>');
        echo('</div>');

        echo('<div class="block clear-both flex">');
        echo('  <div class="pull-left column-40 block "">');
        echo('    <div class="dropsite-address">');
        echo('      <p>' . $dropsite->get('address1') . '</p>');
        echo('      <p>' . $dropsite->get('address2') . '</p>');
        echo('    </div>');
        echo('    <p class="availability-open-now">' . "Site Hours: " . $dropsite->get('availability') . '</p>');
        echo('    <p class="headLabel"><span class="special">Health: </span>' . $dropsite->get('health') . '</p>');
        echo('    <p class="rating"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></p>');
        echo('    <p class="headLabel"><span class="special">Things needed: </span>' . $dropsite->get('categories') . '</p>');
        echo('  <br />  ');
        echo('    <p class="headLabel"><span class="special">Special Requirements: </span>' . $dropsite->get('requirements') . '</p>');
        ?>

        <br><br>
          <?php 
          if($currentUser && $currentUser->get("userType") === 2) { // If user is signed in and an organizational account
            echo('<a id="claim-button" class="dropsite-navbut">Claim</a>');         
          } else {
            echo('<a style=id="favStar" onclick="favoriteSite()" class="bookmark" onclick>★ </a>');
            echo('<a id="pledge-button" style="font-size: 80%" class=""></a>');
          }
          ?>
        <br/>
        <br />
        <p id="claim-success">
          
        </p>

        <?php

        echo('  </div>');
        echo('  <div class="pull-right column-40 block map" id="dropsite-map"></div>');
        echo('</div>');
        echo('<div id="dropsite-id" style="display: none">' . $dropsiteId . '</div>');
        echo('<script>render_map("' . $dropsite->get('address1') . ' ' . $dropsite->get('address2') . '")</script>');
      } catch (ParseException $e) {

        # failure! Print the failure.
        echo("whoops!");
        echo($e->getMessage());
      }

      ?>

      
    </div>

  </body>
</html>

<script>
  $(document).ready(function(){
    var dest = location.search.replace(/^.*?\=/, ''); // Grabs query parameter from url 
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { id: dest },
      url: "siteStatus.php",
      success: function(data){
        if(data.length > 0) {
          $("#pledge-button").html(data);
        } else {
          $("#pledge-button").html("Pledge");
        }
      }
    });

    // If favorited already, star will appear gold
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { id: dest },
      url: "favoriteStatus.php",
      success: function(data){
        if(data === "exists") {
          $("#favStar").css("color", "#ffd700")
        }
      }
    });
  });

  // Adds dropsite to favorites
  function favoriteSite() {
    var dest = location.search.replace(/^.*?\=/, ''); // Grabs query parameter from url 
    $.ajax({
      type: "POST",
      dataType: 'text',
      data: { id: dest },
      url: "favorite.php",
      success: function(data){
        location.reload();
      }
    });
  }
</script>