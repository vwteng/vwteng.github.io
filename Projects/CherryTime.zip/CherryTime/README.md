# CherryTime

How to setup the dev environment

Install Homebrew
```
ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

Install Git
```
brew install git
```

Setup local git repo
```
sudo git clone https://github.com/brandonthai/CherryTime.git [your-local-repo such as /var/www/]
```

Install Composer
```
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
sudo composer self-update
cd [your-local-repo]
sudo composer install
```

Now you can update the website directly by calling:
```
ssh -i [path-to-your-CherryTime.pem] ec2-user@cherryti.me
cd cherrytime/
git pull origin master
sudo cp -a ~/cherrytime/. /var/www/html/
```
