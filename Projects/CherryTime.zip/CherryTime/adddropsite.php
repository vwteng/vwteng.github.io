<?php require_once('session.php');

Use Parse\ParseUser;

$currentUser = ParseUser::getCurrentUser();
if (!$currentUser) {
  $_SESSION['destination'] = 'Location: adddropsite.php';
  header('Location: login.php');
}?>

<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CherryTime</title>
    <meta name="keywords" content="CherryTime, charity, donation, seattle, capstone, informatics">
    <meta name="description" content="Make time for charity.">
    <link rel="shortcut icon" type="image/png" href="img/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.parsecdn.com/js/parse-1.3.5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css" />
  </head>
  <body>
    <header>
      <?php include 'header.php'; ?>
    </header>
    <div class="container">
      <h1>Add a dropsite</h1>

      <!-- Form for adding a drop site -->
      <form id="addDropsiteForm">

        <input type="text" class="form" id="inpName" placeholder="Enter dropsite name (optional)">
        <input type="text"  class="form" id="inpOrganization" placeholder="Enter organization name" required>
        <select class="form" style="color: #556271;" id="inpCause">
          <option value='' disabled selected style='display:none;'>Select organization cause</option>
          <option value="Animal">Animal</option>
          <option value="Arts">Arts</option>
          <option value="Career">Career</option>
          <option value="Children">Children</option>
          <option value="Clothing">Clothing</option>
          <option value="Disabilities">Disabilities</option>
          <option value="Education">Education</option>
          <option value="Environmental">Environmental</option>
          <option value="Food & Hunger">Food & Hunger</option>
          <option value="General">General</option>
          <option value="Health">Health</option>
          <option value="Housing">Housing</option>
          <option value="Libraries">Libraries</option>
          <option value="Military & Veteran">Military & Veteran</option>
          <option value="Technology">Technology</option>
          <option value="Women">Women</option>
        </select>

        <input type="text"  class="form" id="inpCategories" placeholder="Enter categories of accepted items" required>
        <input type="text"  class="form" id="inpAddress1" placeholder="Address" required>
        <input type="text"  class="form" id="inpAddress2" placeholder="City, State, Zip" required>
        <input type="text"  class="form" id="inpAvailability" placeholder="Enter availability" required>

<!--         Enter availability <input type="checkbox" name="always">Always open</input> <br>

        <div class="daily">
          <label>Sunday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
          <br>
          <label>Monday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
          <br>
          <label>Tuesday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
          <br>
          <label>Wednesday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
          <br>
          <label>Thursday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
          <br>
          <label>Friday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
          <br>
          <label>Saturday:</label> <input type="time" class="time search" required> <label>to</label> <input type="time" class="time search" required>
        </div> -->

        <textarea id="inpRequirements" placeholder="Enter requirements" required></textarea>

        <input class="navbut" style="float: right" type="submit" value="Submit">
      </form>
        <a href="index.php"></a><button class="navbut">Cancel</button></a>
    </div>
  </body>
  <script type="text/javascript" src="js/adddropsite.js"></script>
</html>
